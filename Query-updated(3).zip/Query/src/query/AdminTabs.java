/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package query;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author trufmgajtgiof
 */
public class AdminTabs extends javax.swing.JFrame {
    
    private int currentPos = 0; // displaying position of Books
    private static final String DEFAULT_BOOK_QUERY = "SELECT * FROM Books";
    private static final String DEFAULT_UNFINISHED_ORDER_QUERY = "SELECT * FROM Orders WHERE order_status = 'On Hold' OR order_status = 'Pending' OR order_status = 'Confirmed' ORDER BY order_date ASC";
    private static final String DEFAULT_FINISHED_ORDER_QUERY = "SELECT * FROM Orders WHERE order_status = 'Cancelled' OR order_status = 'Finished' ORDER BY order_date DESC";
    private String currentBooksQuery = null;
    private String currentOrdersQuery = null;
    private String username = null;
    private LocalDate localDate = LocalDate.now();        
    private final String DEFAULT_REPORT_QUERY = "SELECT * FROM Orders WHERE order_date = '"+DateTimeFormatter.ofPattern("yyy/MM/dd").format(localDate)+"'";
    
    public String getUsername(){
        return username;
    }
    
    public void setUsername(String id){
        username = id;
    }
    
    public void setCurrentBooksQuery(String query){
        currentBooksQuery = query;
    }
    
    public String getCurrentBooksQuery(){
        return currentBooksQuery;
    }
    
    public void setCurrentOrdersQuery(String query){
        currentOrdersQuery = query;
    }
    
    public String getCurrentOrdersQuery(){
        return currentOrdersQuery;
    }

    /**
     * Creates new form NewJFrame
     */
    public AdminTabs() {
        initComponents(); // initialize GUI
        getConnection(); // connect to MS SQL Server
        adminShowBookList(DEFAULT_BOOK_QUERY); // show book list for admin tab
        ordersShowUnfinishedOrdersList(DEFAULT_UNFINISHED_ORDER_QUERY);
        ordersShowFinishedOrdersList(DEFAULT_FINISHED_ORDER_QUERY);
        showReport(DEFAULT_REPORT_QUERY);
    }
    
    String ImgPath = null;
        
    public void close(){
        WindowEvent panelClosingEvent = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(panelClosingEvent);
    }
    
    public Connection getConnection(){
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Not Connected");
            return null;
        }
    }
    
    public boolean checkInput(){
        if ( adminISBNField.getText() == null ||
                adminTitleField.getText() == null ||
                adminAuthorField.getText() == null ||
                adminLanguageField.getText() == null ||
                adminPagesField.getText() == null ||
                adminCategoryField.getText() == null ||
                adminPublisherField.getText() == null ||
                adminYearField.getText() == null ||
                adminPriceField.getText() == null )
            return false;
        else{
            try{
                Float.parseFloat(adminPriceField.getText());
                return true;
            }
            catch (Exception e){
                return false;
            }
        }
    }
    
    public ImageIcon adminResizeImage(String imagePath, byte[] pic){
        ImageIcon myImage = null;
        
        if (imagePath != null){
            myImage = new ImageIcon(imagePath);
        }
        else{
            myImage = new ImageIcon(pic);
        }
        
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(adminImage.getWidth(), adminImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        
        return image;
    }
    
    //display result table
    public ArrayList<Book> getBookList(String query){
        
        ArrayList<Book> bookList = new ArrayList<Book>();
        Connection con = getConnection();
            
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Book books;
            
            while (rs.next()){
                books = new Book(rs.getString("isbn"), rs.getString("title"), rs.getString("author"), rs.getString("language"), rs.getInt("pages"), rs.getString("category"), rs.getString("publisher"), Integer.parseInt(rs.getString("publishYear")), Float.parseFloat(rs.getString("price")),rs.getBytes("img"));
                bookList.add(books);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return bookList;
    }
    
    public ArrayList<Orders> getOrdersList(String query){
        
        ArrayList<Orders> ordersList = new ArrayList<Orders>();
        Connection con = getConnection();
            
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Orders orders;
            
            while (rs.next()){
                orders = new Orders(Integer.parseInt(rs.getString("order_ID")), rs.getString("username"), rs.getString("isbn"), rs.getString("order_date"), rs.getString("order_status"));
                ordersList.add(orders);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return ordersList;
    }
    
    public void ordersShowUnfinishedOrdersList(String query){
        ArrayList<Orders> result = getOrdersList(query);
        DefaultTableModel model = (DefaultTableModel)ordersUnfinishedResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[4];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getOrderID();
            currentRow[1] = result.get(i).getISBN();
            currentRow[2] = result.get(i).getDate();
            currentRow[3] = result.get(i).getStatus();
            
            
            model.addRow(currentRow);
        }
    }
    
    public void ordersShowFinishedOrdersList(String query){
        ArrayList<Orders> result = getOrdersList(query);
        DefaultTableModel model = (DefaultTableModel)ordersFinishedResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[4];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getOrderID();
            currentRow[1] = result.get(i).getISBN();
            currentRow[2] = result.get(i).getDate();
            currentRow[3] = result.get(i).getStatus();
            
            
            model.addRow(currentRow);
        }
    }
    
    public void adminShowBookList(String query){
        ArrayList<Book> result = getBookList(query);
        DefaultTableModel model = (DefaultTableModel)adminResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[7];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getISBN();
            currentRow[1] = result.get(i).getTitle();
            currentRow[2] = result.get(i).getAuthor();
            currentRow[3] = result.get(i).getLanguage();
            currentRow[4] = result.get(i).getPages();
            currentRow[5] = result.get(i).getCategory();
            currentRow[6] = result.get(i).getPrice();
            
            model.addRow(currentRow);
        }
    }
    
    public void showReport(String query){
        ArrayList<Orders> result = getOrdersList(query);
        DefaultTableModel model = (DefaultTableModel)reportTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[4];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getOrderID();
            currentRow[1] = result.get(i).getISBN();
            currentRow[2] = result.get(i).getDate();
            currentRow[3] = result.get(i).getStatus();
            
            model.addRow(currentRow);
        }
    }
    
    public void adminShowChosenBook(int index, String query){
        adminISBNField.setText(getBookList(query).get(index).getISBN());
        adminTitleField.setText(getBookList(query).get(index).getTitle());
        adminAuthorField.setText(getBookList(query).get(index).getAuthor());
        adminLanguageField.setText(getBookList(query).get(index).getLanguage());
        adminPagesField.setText(Integer.toString(getBookList(query).get(index).getPages()));
        adminCategoryField.setText(getBookList(query).get(index).getCategory());
        adminPublisherField.setText(getBookList(query).get(index).getPublisher());
        adminYearField.setText(Integer.toString(getBookList(query).get(index).getYear()));
        adminPriceField.setText(Float.toString(getBookList(query).get(index).getPrice()));
        adminImage.setIcon(adminResizeImage(null, getBookList(query).get(index).getPicture()));
    }
    
    public void ordersShowChosenUnfinishedOrders(){
        if (currentOrdersQuery == null)
            currentOrdersQuery = DEFAULT_UNFINISHED_ORDER_QUERY;
        PopUpChosenOrder chosen = new PopUpChosenOrder();
        int index = ordersUnfinishedResultTable.getSelectedRow();
        chosen.adjustOrderIDText(Integer.toString(getOrdersList(currentOrdersQuery).get(index).getOrderID()));
        chosen.adjustOrderUserText(getOrdersList(currentOrdersQuery).get(index).getUsername());
        chosen.adjustOrderISBNText(getOrdersList(currentOrdersQuery).get(index).getISBN());
        chosen.adjustOrderDateText(getOrdersList(currentOrdersQuery).get(index).getDate());
        chosen.adjustOrderStatusText(getOrdersList(currentOrdersQuery).get(index).getStatus());        
    }
    
    public void ordersShowChosenFinishedOrders(){
        if (currentOrdersQuery == null)
            currentOrdersQuery = DEFAULT_FINISHED_ORDER_QUERY;
        PopUpChosenOrder chosen = new PopUpChosenOrder();
        int index = ordersFinishedResultTable.getSelectedRow();
        chosen.adjustOrderIDText(Integer.toString(getOrdersList(currentOrdersQuery).get(index).getOrderID()));
        chosen.adjustOrderUserText(getOrdersList(currentOrdersQuery).get(index).getUsername());
        chosen.adjustOrderISBNText(getOrdersList(currentOrdersQuery).get(index).getISBN());
        chosen.adjustOrderDateText(getOrdersList(currentOrdersQuery).get(index).getDate());
        chosen.adjustOrderStatusText(getOrdersList(currentOrdersQuery).get(index).getStatus());        
    } 
     public void display(){
         /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserTabs().setVisible(true);
            }
        });
     }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTabsPane = new javax.swing.JTabbedPane();
        ordersPanel = new javax.swing.JPanel();
        ordersSubPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ordersTerminology = new javax.swing.JTextArea();
        ordersAdjustButton = new javax.swing.JButton();
        ordersSearchField = new javax.swing.JTextField();
        ordersSearchLabel = new javax.swing.JLabel();
        ordersSearchUnfinishedButton = new javax.swing.JButton();
        ordersUnfinishedResultPane = new javax.swing.JScrollPane();
        ordersUnfinishedResultTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        ordersFinishedResultPane = new javax.swing.JScrollPane();
        ordersFinishedResultTable = new javax.swing.JTable();
        ordersSubPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ordersTerminology1 = new javax.swing.JTextArea();
        ordersAdjustButton1 = new javax.swing.JButton();
        ordersSearchField1 = new javax.swing.JTextField();
        ordersSearchLabel1 = new javax.swing.JLabel();
        ordersSearchFinishedButton = new javax.swing.JButton();
        adminMainPanel = new javax.swing.JPanel();
        adminSearchPanel = new javax.swing.JPanel();
        adminSearchLabel = new javax.swing.JLabel();
        adminSearchField = new javax.swing.JTextField();
        adminSearchShowAllButton = new javax.swing.JButton();
        adminSearchButton = new javax.swing.JButton();
        adminToFirstButton = new javax.swing.JButton();
        adminPreviousButton = new javax.swing.JButton();
        adminNextButton = new javax.swing.JButton();
        adminToLastButton = new javax.swing.JButton();
        adminScrollInfo = new javax.swing.JScrollPane();
        adminInformationPanel = new javax.swing.JPanel();
        adminISBNLabel = new javax.swing.JLabel();
        adminISBNField = new javax.swing.JTextField();
        adminTitleField = new javax.swing.JTextField();
        adminTitleLabel = new javax.swing.JLabel();
        adminAuthorField = new javax.swing.JTextField();
        adminAuthorLabel = new javax.swing.JLabel();
        adminLanguageField = new javax.swing.JTextField();
        adminLanguageLabel = new javax.swing.JLabel();
        adminPagesField = new javax.swing.JTextField();
        adminPagesLabel = new javax.swing.JLabel();
        adminCategoryField = new javax.swing.JTextField();
        adminCategoryLabel = new javax.swing.JLabel();
        adminPublisherField = new javax.swing.JTextField();
        adminPublisherLabel = new javax.swing.JLabel();
        adminYearLabel = new javax.swing.JLabel();
        adminYearField = new javax.swing.JTextField();
        adminPriceField = new javax.swing.JTextField();
        adminPriceLabel = new javax.swing.JLabel();
        adminImage = new javax.swing.JLabel();
        chooseImgButton = new javax.swing.JButton();
        adminInsertButton = new javax.swing.JButton();
        adminUpdateButton = new javax.swing.JButton();
        adminDeleteButton = new javax.swing.JButton();
        adminSearchResultPane = new javax.swing.JScrollPane();
        adminResultTable = new javax.swing.JTable();
        reportPanel = new javax.swing.JPanel();
        reportInfoPanel = new javax.swing.JPanel();
        promptLabel = new javax.swing.JLabel();
        reportInfoField = new javax.swing.JTextField();
        reportNoteLabel = new javax.swing.JLabel();
        seeReportButton = new javax.swing.JButton();
        reportScrollPane = new javax.swing.JScrollPane();
        reportTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bookstore Application");

        mainTabsPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Main Tabs", javax.swing.border.TitledBorder.RIGHT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 20))); // NOI18N
        mainTabsPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersSubPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ordersTerminology.setColumns(20);
        ordersTerminology.setFont(new java.awt.Font("Monospaced", 0, 15)); // NOI18N
        ordersTerminology.setRows(5);
        ordersTerminology.setText("Terminologies:\n\t. \"On Hold\": The order is not completed due to out of stock.\n\t. \"Confirmed\": The order is approved and ready for customer to pick up.\n\t. \"Pending\": The order is made and need to be approved.");
        jScrollPane1.setViewportView(ordersTerminology);

        ordersAdjustButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ordersAdjustButton.setText("Adjust Order");
        ordersAdjustButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ordersAdjustButtonActionPerformed(evt);
            }
        });

        ordersSearchField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        ordersSearchLabel.setText("Search an order");

        ordersSearchUnfinishedButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ordersSearchUnfinishedButton.setText("Search");
        ordersSearchUnfinishedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ordersSearchUnfinishedButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ordersSubPanelLayout = new javax.swing.GroupLayout(ordersSubPanel);
        ordersSubPanel.setLayout(ordersSubPanelLayout);
        ordersSubPanelLayout.setHorizontalGroup(
            ordersSubPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersSubPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(ordersSubPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ordersSubPanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 824, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ordersAdjustButton))
                    .addGroup(ordersSubPanelLayout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(ordersSearchLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(ordersSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(ordersSearchUnfinishedButton)))
                .addContainerGap(155, Short.MAX_VALUE))
        );
        ordersSubPanelLayout.setVerticalGroup(
            ordersSubPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersSubPanelLayout.createSequentialGroup()
                .addGroup(ordersSubPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ordersSubPanelLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(ordersAdjustButton))
                    .addGroup(ordersSubPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(ordersSubPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ordersSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ordersSearchLabel)
                    .addComponent(ordersSearchUnfinishedButton))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        ordersUnfinishedResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "All Unfinished Orders (Oldest to Newest)", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        ordersUnfinishedResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersUnfinishedResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ordersUnfinishedResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order Number", "ISBN", "Order Date", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ordersUnfinishedResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ordersUnfinishedResultTableMouseClicked(evt);
            }
        });
        ordersUnfinishedResultPane.setViewportView(ordersUnfinishedResultTable);

        javax.swing.GroupLayout ordersPanelLayout = new javax.swing.GroupLayout(ordersPanel);
        ordersPanel.setLayout(ordersPanelLayout);
        ordersPanelLayout.setHorizontalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ordersSubPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ordersPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(ordersUnfinishedResultPane)
                    .addContainerGap()))
        );
        ordersPanelLayout.setVerticalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersPanelLayout.createSequentialGroup()
                .addGap(285, 285, 285)
                .addComponent(ordersSubPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(452, Short.MAX_VALUE))
            .addGroup(ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(ordersPanelLayout.createSequentialGroup()
                    .addGap(23, 23, 23)
                    .addComponent(ordersUnfinishedResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(623, Short.MAX_VALUE)))
        );

        mainTabsPane.addTab("Unfinished Orders", ordersPanel);

        ordersFinishedResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Finished Orders (Newest To Oldest)", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        ordersFinishedResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersFinishedResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ordersFinishedResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order Number", "ISBN", "Order Date", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ordersFinishedResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ordersFinishedResultTableMouseClicked(evt);
            }
        });
        ordersFinishedResultPane.setViewportView(ordersFinishedResultTable);

        ordersSubPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ordersTerminology1.setColumns(20);
        ordersTerminology1.setFont(new java.awt.Font("Monospaced", 0, 15)); // NOI18N
        ordersTerminology1.setRows(5);
        ordersTerminology1.setText("Terminologies:\n\t. \"Cancelled\": The order is cancelled by customer.\n\t. \"Finished\": The order is confirmed and picked up by customer.");
        jScrollPane2.setViewportView(ordersTerminology1);

        ordersAdjustButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ordersAdjustButton1.setText("Adjust Order");
        ordersAdjustButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ordersAdjustButton1ActionPerformed(evt);
            }
        });

        ordersSearchField1.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersSearchLabel1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        ordersSearchLabel1.setText("Search an order");

        ordersSearchFinishedButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ordersSearchFinishedButton.setText("Search");
        ordersSearchFinishedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ordersSearchFinishedButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ordersSubPanel1Layout = new javax.swing.GroupLayout(ordersSubPanel1);
        ordersSubPanel1.setLayout(ordersSubPanel1Layout);
        ordersSubPanel1Layout.setHorizontalGroup(
            ordersSubPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(ordersSubPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 824, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ordersAdjustButton1))
                    .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(ordersSearchLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(ordersSearchField1, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(ordersSearchFinishedButton)))
                .addContainerGap(155, Short.MAX_VALUE))
        );
        ordersSubPanel1Layout.setVerticalGroup(
            ordersSubPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                .addGroup(ordersSubPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(ordersAdjustButton1))
                    .addGroup(ordersSubPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(ordersSubPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ordersSearchField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ordersSearchLabel1)
                    .addComponent(ordersSearchFinishedButton))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ordersFinishedResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1182, Short.MAX_VALUE)
                    .addComponent(ordersSubPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ordersFinishedResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ordersSubPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(458, Short.MAX_VALUE))
        );

        mainTabsPane.addTab("Finished Orders", jPanel1);

        adminSearchPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminSearchPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        adminSearchLabel.setText("Enter the keywords of your book");

        adminSearchField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        adminSearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchFieldActionPerformed(evt);
            }
        });

        adminSearchShowAllButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminSearchShowAllButton.setText("Show All");
        adminSearchShowAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchShowAllButtonActionPerformed(evt);
            }
        });

        adminSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminSearchButton.setText("Search");
        adminSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchButtonActionPerformed(evt);
            }
        });

        adminToFirstButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminToFirstButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/resultset-first-icon.png"))); // NOI18N
        adminToFirstButton.setText("First");
        adminToFirstButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminToFirstButtonActionPerformed(evt);
            }
        });

        adminPreviousButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPreviousButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Arrow-previous-4-icon.png"))); // NOI18N
        adminPreviousButton.setText("Previous");
        adminPreviousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminPreviousButtonActionPerformed(evt);
            }
        });

        adminNextButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminNextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/next-icon.png"))); // NOI18N
        adminNextButton.setText("Next");
        adminNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminNextButtonActionPerformed(evt);
            }
        });

        adminToLastButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminToLastButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-go-last-view-icon.png"))); // NOI18N
        adminToLastButton.setText("Last");
        adminToLastButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminToLastButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout adminSearchPanelLayout = new javax.swing.GroupLayout(adminSearchPanel);
        adminSearchPanel.setLayout(adminSearchPanelLayout);
        adminSearchPanelLayout.setHorizontalGroup(
            adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminSearchPanelLayout.createSequentialGroup()
                        .addComponent(adminSearchLabel)
                        .addGap(18, 18, 18)
                        .addComponent(adminSearchField)
                        .addGap(62, 62, 62))
                    .addGroup(adminSearchPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(adminSearchButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminSearchShowAllButton)
                        .addGap(62, 62, 62)
                        .addComponent(adminToFirstButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminPreviousButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminNextButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminToLastButton)
                        .addGap(40, 40, 40))))
        );
        adminSearchPanelLayout.setVerticalGroup(
            adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminSearchLabel)
                    .addComponent(adminSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminSearchShowAllButton)
                    .addComponent(adminSearchButton)
                    .addComponent(adminToFirstButton)
                    .addComponent(adminPreviousButton)
                    .addComponent(adminNextButton)
                    .addComponent(adminToLastButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        adminInformationPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminInformationPanel.setAutoscrolls(true);
        adminInformationPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminISBNLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminISBNLabel.setText("ISBN");

        adminISBNField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminTitleField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminTitleLabel.setText("Title");

        adminAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminAuthorLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminAuthorLabel.setText("Author");

        adminLanguageField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminLanguageLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminLanguageLabel.setText("Language");

        adminPagesField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPagesLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPagesLabel.setText("Pages");

        adminCategoryField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        adminCategoryField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminCategoryFieldActionPerformed(evt);
            }
        });

        adminCategoryLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminCategoryLabel.setText("Category");

        adminPublisherField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPublisherLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPublisherLabel.setText("Publisher");

        adminYearLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminYearLabel.setText("Publish Year");

        adminYearField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPriceField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPriceLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPriceLabel.setText("Price");

        adminImage.setBackground(new java.awt.Color(102, 153, 255));
        adminImage.setOpaque(true);

        chooseImgButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        chooseImgButton.setText("Choose Picture");
        chooseImgButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseImgButtonActionPerformed(evt);
            }
        });

        adminInsertButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminInsertButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Button-Add-icon.png"))); // NOI18N
        adminInsertButton.setText("Insert");
        adminInsertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminInsertButtonActionPerformed(evt);
            }
        });

        adminUpdateButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminUpdateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-edit-redo-icon.png"))); // NOI18N
        adminUpdateButton.setText("Update");
        adminUpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminUpdateButtonActionPerformed(evt);
            }
        });

        adminDeleteButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminDeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/cancel-icon.png"))); // NOI18N
        adminDeleteButton.setText("Delete");
        adminDeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminDeleteButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout adminInformationPanelLayout = new javax.swing.GroupLayout(adminInformationPanel);
        adminInformationPanel.setLayout(adminInformationPanelLayout);
        adminInformationPanelLayout.setHorizontalGroup(
            adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(adminPublisherLabel)
                            .addComponent(adminYearLabel)
                            .addComponent(adminPriceLabel)
                            .addComponent(adminCategoryLabel)
                            .addComponent(adminPagesLabel)
                            .addComponent(adminLanguageLabel)
                            .addComponent(adminAuthorLabel)
                            .addComponent(adminTitleLabel)
                            .addComponent(adminISBNLabel))
                        .addGap(30, 30, 30)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(adminISBNField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 509, Short.MAX_VALUE)
                            .addComponent(adminTitleField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminAuthorField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminLanguageField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPagesField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminCategoryField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPublisherField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminYearField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPriceField)))
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(adminInsertButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(adminUpdateButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminDeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addComponent(adminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(chooseImgButton)
                .addGap(172, 172, 172))
        );
        adminInformationPanelLayout.setVerticalGroup(
            adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminISBNLabel)
                            .addComponent(adminISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminTitleLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminAuthorLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminLanguageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminLanguageLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPagesField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPagesLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminCategoryLabel)
                            .addComponent(adminCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPublisherLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminYearField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminYearLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPriceLabel))
                        .addGap(42, 42, 42))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminInformationPanelLayout.createSequentialGroup()
                        .addComponent(adminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(chooseImgButton)
                        .addGap(10, 10, 10)))
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminInsertButton)
                    .addComponent(adminUpdateButton)
                    .addComponent(adminDeleteButton))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        adminScrollInfo.setViewportView(adminInformationPanel);

        adminSearchResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        adminSearchResultPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        adminSearchResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        adminResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ISBN", "Title", "Author", "Language", "Pages", "Category", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminResultTableMouseClicked(evt);
            }
        });
        adminSearchResultPane.setViewportView(adminResultTable);

        javax.swing.GroupLayout adminMainPanelLayout = new javax.swing.GroupLayout(adminMainPanel);
        adminMainPanel.setLayout(adminMainPanelLayout);
        adminMainPanelLayout.setHorizontalGroup(
            adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(adminSearchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(adminScrollInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 1182, Short.MAX_VALUE)
                    .addComponent(adminSearchResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1182, Short.MAX_VALUE))
                .addContainerGap())
        );
        adminMainPanelLayout.setVerticalGroup(
            adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminSearchResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adminSearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adminScrollInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainTabsPane.addTab("Admin's ManagementTools", adminMainPanel);

        promptLabel.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        promptLabel.setText("Enter the date you want to see its report");

        reportInfoField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        reportInfoField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportInfoFieldActionPerformed(evt);
            }
        });

        reportNoteLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        reportNoteLabel.setText("Note: You must input in the form of YYYY-MM-DD to get the result!");

        seeReportButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        seeReportButton.setText("See Report");
        seeReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seeReportButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout reportInfoPanelLayout = new javax.swing.GroupLayout(reportInfoPanel);
        reportInfoPanel.setLayout(reportInfoPanelLayout);
        reportInfoPanelLayout.setHorizontalGroup(
            reportInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportInfoPanelLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(reportInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reportInfoPanelLayout.createSequentialGroup()
                        .addComponent(reportNoteLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(seeReportButton))
                    .addGroup(reportInfoPanelLayout.createSequentialGroup()
                        .addComponent(promptLabel)
                        .addGap(85, 85, 85)
                        .addComponent(reportInfoField, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        reportInfoPanelLayout.setVerticalGroup(
            reportInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportInfoPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(reportInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(promptLabel)
                    .addComponent(reportInfoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(reportInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(reportInfoPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reportNoteLabel)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reportInfoPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                        .addComponent(seeReportButton)
                        .addContainerGap())))
        );

        reportTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Order Number", "Username", "ISBN", "Date", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        reportScrollPane.setViewportView(reportTable);

        javax.swing.GroupLayout reportPanelLayout = new javax.swing.GroupLayout(reportPanel);
        reportPanel.setLayout(reportPanelLayout);
        reportPanelLayout.setHorizontalGroup(
            reportPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, reportPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reportInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(240, 240, 240))
            .addGroup(reportPanelLayout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addComponent(reportScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );
        reportPanelLayout.setVerticalGroup(
            reportPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reportPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(reportInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(reportScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(415, Short.MAX_VALUE))
        );

        mainTabsPane.addTab("Report", reportPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainTabsPane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainTabsPane)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void adminNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminNextButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
            setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentBooksQuery).size()-1;
        if (currentPos != finalPos)
            adminShowChosenBook(++currentPos, currentBooksQuery);
        else
            JOptionPane.showMessageDialog(null, "You have reached the end of our bookstore!");
    }//GEN-LAST:event_adminNextButtonActionPerformed

    private void adminSearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminSearchFieldActionPerformed

    private void adminToFirstButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminToFirstButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
            setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            adminShowChosenBook(0, currentBooksQuery);
            currentPos = 0;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the top of our book list!");
    }//GEN-LAST:event_adminToFirstButtonActionPerformed

    private void adminDeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminDeleteButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("DELETE FROM Books WHERE isbn = ?;");
                ps.setString(1, adminISBNField.getText());
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Book Deleted Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Delete Failed!\nBook's ISBN not found!\n It is best that you search for the book first, then choose from it!");
    }//GEN-LAST:event_adminDeleteButtonActionPerformed

    private void adminUpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminUpdateButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("UPDATE Books SET title = ?, author = ?, language = ?, pages = ?, category = ?, publisher = ?, publishYear = ?, price = ?, img = ? WHERE isbn = ?;");
                ps.setString(10, adminISBNField.getText());
                ps.setString(1, adminTitleField.getText());
                ps.setString(2, adminAuthorField.getText());
                ps.setString(3, adminLanguageField.getText());
                ps.setString(4, adminPagesField.getText());
                ps.setString(5, adminCategoryField.getText());
                ps.setString(6, adminPublisherField.getText());
                ps.setString(7, adminYearField.getText());
                ps.setString(8, adminPriceField.getText());

                InputStream img = new FileInputStream(new File(ImgPath));
                ps.setBlob(9, img);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Data Updated Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Update Failed!\nOne or more fields are empty!");
    }//GEN-LAST:event_adminUpdateButtonActionPerformed

    private void adminInsertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminInsertButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("INSERT INTO Books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");
                ps.setString(1, adminISBNField.getText());
                ps.setString(2, adminTitleField.getText());
                ps.setString(3, adminAuthorField.getText());
                ps.setString(4, adminLanguageField.getText());
                ps.setString(5, adminPagesField.getText());
                ps.setString(6, adminCategoryField.getText());
                ps.setString(7, adminPublisherField.getText());
                ps.setString(8, adminYearField.getText());
                ps.setString(9, adminPriceField.getText());

                InputStream img = new FileInputStream(new File(ImgPath));
                ps.setBlob(10, img);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Data Inserted Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        JOptionPane.showMessageDialog(null, "Insertion Failed!\nOne or more fields are empty!");
    }//GEN-LAST:event_adminInsertButtonActionPerformed

    private void chooseImgButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseImgButtonActionPerformed
        // TODO add your handling code here:
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));

        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION){
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            System.out.println(path);
            adminImage.setIcon(adminResizeImage(path, null));
            ImgPath = path;
        }
        else
        System.out.println("No file was selected");
    }//GEN-LAST:event_chooseImgButtonActionPerformed

    private void adminCategoryFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminCategoryFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminCategoryFieldActionPerformed

    private void adminToLastButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminToLastButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
            setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentBooksQuery).size()-1;
        if (currentPos != finalPos){
            adminShowChosenBook(finalPos, currentBooksQuery);
            currentPos = finalPos;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the end of our book list!");
    }//GEN-LAST:event_adminToLastButtonActionPerformed

    private void adminPreviousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminPreviousButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
            setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            adminShowChosenBook(--currentPos, currentBooksQuery);
        }
        else
            JOptionPane.showMessageDialog(null, "You have reached the top of the list!");
    }//GEN-LAST:event_adminPreviousButtonActionPerformed

    private void adminResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminResultTableMouseClicked
        // TODO add your handling code here:
        if (currentBooksQuery == null)
            setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int index = adminResultTable.getSelectedRow();
        adminShowChosenBook(index, currentBooksQuery);
        currentPos = index;
    }//GEN-LAST:event_adminResultTableMouseClicked

    private void adminSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchButtonActionPerformed
        // TODO add your handling code here:
        
        String query = "SELECT * FROM Books WHERE isbn LIKE '%"+adminSearchField.getText()+"%' "
                + "OR title LIKE '%"+adminSearchField.getText()+"%' "
                + "OR author LIKE '%"+adminSearchField.getText()+"%'"
                + "OR language LIKE '%"+adminSearchField.getText()+"%'"
                + "OR pages LIKE '%"+adminSearchField.getText()+"%'"
                + "OR category LIKE '%"+adminSearchField.getText()+"%'"
                + "OR publisher LIKE '%"+adminSearchField.getText()+"%'"
                + "OR publishYear LIKE '%"+adminSearchField.getText()+"%'"
                + "OR price LIKE '%"+adminSearchField.getText()+"%';";
        setCurrentBooksQuery(query);    
        adminShowBookList(currentBooksQuery);        
        
    }//GEN-LAST:event_adminSearchButtonActionPerformed

    private void adminSearchShowAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchShowAllButtonActionPerformed
        // TODO add your handling code here:
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        adminShowBookList(currentBooksQuery);
    }//GEN-LAST:event_adminSearchShowAllButtonActionPerformed

    private void ordersSearchUnfinishedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ordersSearchUnfinishedButtonActionPerformed
        // TODO add your handling code here:
        setCurrentOrdersQuery("SELECT * FROM Orders WHERE order_id LIKE '%"+ordersSearchField.getText()+"%'"
                + "OR username LIKE '%"+ordersSearchField.getText()+"%' "
                        + "OR isbn LIKE '%"+ordersSearchField.getText()+"%' "
                                + "OR order_date LIKE '%"+ordersSearchField.getText()+"%' ");
        ordersShowUnfinishedOrdersList(currentOrdersQuery);
    }//GEN-LAST:event_ordersSearchUnfinishedButtonActionPerformed

    private void ordersUnfinishedResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ordersUnfinishedResultTableMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_ordersUnfinishedResultTableMouseClicked

    private void ordersFinishedResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ordersFinishedResultTableMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_ordersFinishedResultTableMouseClicked

    private void ordersAdjustButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ordersAdjustButtonActionPerformed
        // TODO add your handling code here:
        ordersShowChosenUnfinishedOrders();
    }//GEN-LAST:event_ordersAdjustButtonActionPerformed

    private void ordersAdjustButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ordersAdjustButton1ActionPerformed
        // TODO add your handling code here:
        ordersShowChosenFinishedOrders();
    }//GEN-LAST:event_ordersAdjustButton1ActionPerformed

    private void ordersSearchFinishedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ordersSearchFinishedButtonActionPerformed
        // TODO add your handling code here:
        setCurrentOrdersQuery("SELECT * FROM Orders WHERE order_id LIKE '%"+ordersSearchField.getText()+"%'"
                + "OR username LIKE '%"+ordersSearchField.getText()+"%' "
                        + "OR isbn LIKE '%"+ordersSearchField.getText()+"%' "
                                + "OR order_date LIKE '%"+ordersSearchField.getText()+"%' ");
        ordersShowFinishedOrdersList(currentOrdersQuery);
    }//GEN-LAST:event_ordersSearchFinishedButtonActionPerformed

    private void reportInfoFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportInfoFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_reportInfoFieldActionPerformed

    private void seeReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seeReportButtonActionPerformed
        // TODO add your handling code here:
        String query = "SELECT * FROM Orders WHERE order_date = '"+reportInfoField.getText()+"'";
        showReport(query);
    }//GEN-LAST:event_seeReportButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminTabs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adminAuthorField;
    private javax.swing.JLabel adminAuthorLabel;
    private javax.swing.JTextField adminCategoryField;
    private javax.swing.JLabel adminCategoryLabel;
    private javax.swing.JButton adminDeleteButton;
    private javax.swing.JTextField adminISBNField;
    private javax.swing.JLabel adminISBNLabel;
    private javax.swing.JLabel adminImage;
    private javax.swing.JPanel adminInformationPanel;
    private javax.swing.JButton adminInsertButton;
    private javax.swing.JTextField adminLanguageField;
    private javax.swing.JLabel adminLanguageLabel;
    private javax.swing.JPanel adminMainPanel;
    private javax.swing.JButton adminNextButton;
    private javax.swing.JTextField adminPagesField;
    private javax.swing.JLabel adminPagesLabel;
    private javax.swing.JButton adminPreviousButton;
    private javax.swing.JTextField adminPriceField;
    private javax.swing.JLabel adminPriceLabel;
    private javax.swing.JTextField adminPublisherField;
    private javax.swing.JLabel adminPublisherLabel;
    private javax.swing.JTable adminResultTable;
    private javax.swing.JScrollPane adminScrollInfo;
    private javax.swing.JButton adminSearchButton;
    private javax.swing.JTextField adminSearchField;
    private javax.swing.JLabel adminSearchLabel;
    private javax.swing.JPanel adminSearchPanel;
    private javax.swing.JScrollPane adminSearchResultPane;
    private javax.swing.JButton adminSearchShowAllButton;
    private javax.swing.JTextField adminTitleField;
    private javax.swing.JLabel adminTitleLabel;
    private javax.swing.JButton adminToFirstButton;
    private javax.swing.JButton adminToLastButton;
    private javax.swing.JButton adminUpdateButton;
    private javax.swing.JTextField adminYearField;
    private javax.swing.JLabel adminYearLabel;
    private javax.swing.JButton chooseImgButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane mainTabsPane;
    private javax.swing.JButton ordersAdjustButton;
    private javax.swing.JButton ordersAdjustButton1;
    private javax.swing.JScrollPane ordersFinishedResultPane;
    private javax.swing.JTable ordersFinishedResultTable;
    private javax.swing.JPanel ordersPanel;
    private javax.swing.JTextField ordersSearchField;
    private javax.swing.JTextField ordersSearchField1;
    private javax.swing.JButton ordersSearchFinishedButton;
    private javax.swing.JLabel ordersSearchLabel;
    private javax.swing.JLabel ordersSearchLabel1;
    private javax.swing.JButton ordersSearchUnfinishedButton;
    private javax.swing.JPanel ordersSubPanel;
    private javax.swing.JPanel ordersSubPanel1;
    private javax.swing.JTextArea ordersTerminology;
    private javax.swing.JTextArea ordersTerminology1;
    private javax.swing.JScrollPane ordersUnfinishedResultPane;
    private javax.swing.JTable ordersUnfinishedResultTable;
    private javax.swing.JLabel promptLabel;
    private javax.swing.JTextField reportInfoField;
    private javax.swing.JPanel reportInfoPanel;
    private javax.swing.JLabel reportNoteLabel;
    private javax.swing.JPanel reportPanel;
    private javax.swing.JScrollPane reportScrollPane;
    private javax.swing.JTable reportTable;
    private javax.swing.JButton seeReportButton;
    // End of variables declaration//GEN-END:variables
}
