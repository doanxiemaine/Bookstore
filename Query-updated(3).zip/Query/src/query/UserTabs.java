/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package query;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author trufmgajtgiof
 */
public class UserTabs extends javax.swing.JFrame {

    private int currentPos = 0; // displaying position of Books
    private static final String DEFAULT_BOOK_QUERY = "SELECT * FROM Books";
    private String currentBooksQuery = null;
    private String username = null;
    private LocalDate localDate = LocalDate.now();
    /**
     * Creates new form UserTabs
     */
    public UserTabs() {
        initComponents();
        booksShowBookList(DEFAULT_BOOK_QUERY);
    }
    
    public void close(){
        WindowEvent panelClosingEvent = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(panelClosingEvent);
    }
    
    public String getUsername(){
        return username;
    }
    
    public void setUsername(String id){
        username = id;
    }
    
    public void setCurrentBooksQuery(String query){
        currentBooksQuery = query;
    }
    
    public String getCurrentBooksQuery(){
        return currentBooksQuery;
    }
    
    public Connection getConnection(){
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Not Connected");
            return null;
        }
    }
    
    public boolean checkInput(){
        if ( booksISBNField.getText() == null ||
                booksTitleField.getText() == null ||
                booksAuthorField.getText() == null ||
                booksLanguageField.getText() == null ||
                booksPagesField.getText() == null ||
                booksCategoryField.getText() == null ||
                booksPublisherField.getText() == null ||
                booksYearField.getText() == null ||
                booksPriceField.getText() == null )
            return false;
        else{
            try{
                Float.parseFloat(booksPriceField.getText());
                return true;
            }
            catch (Exception e){
                return false;
            }
        }
    }
    
    public ImageIcon booksResizeImage(String imagePath, byte[] pic){
        ImageIcon myImage = null;
        
        if (imagePath != null){
            myImage = new ImageIcon(imagePath);
        }
        else{
            myImage = new ImageIcon(pic);
        }
        
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(booksImage.getWidth(), booksImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        
        return image;
    }
    
    public ArrayList<Book> getBookList(String query){
        
        ArrayList<Book> bookList = new ArrayList<Book>();
        Connection con = getConnection();
            
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Book books;
            
            while (rs.next()){
                books = new Book(rs.getString("isbn"), rs.getString("title"), rs.getString("author"), rs.getString("language"), rs.getInt("pages"), rs.getString("category"), rs.getString("publisher"), Integer.parseInt(rs.getString("publishYear")), Float.parseFloat(rs.getString("price")),rs.getBytes("img"));
                bookList.add(books);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminTabs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return bookList;
    }
    
    public void booksShowBookList(String query){
        ArrayList<Book> result = getBookList(query);
        DefaultTableModel model = (DefaultTableModel)booksResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[7];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getISBN();
            currentRow[1] = result.get(i).getTitle();
            currentRow[2] = result.get(i).getAuthor();
            currentRow[3] = result.get(i).getLanguage();
            currentRow[4] = result.get(i).getPages();
            currentRow[5] = result.get(i).getCategory();
            currentRow[6] = result.get(i).getPrice();
            
            model.addRow(currentRow);
        }
    }
    
    public void booksShowChosenBook(int index, String query){
        booksISBNField.setText(getBookList(query).get(index).getISBN());
        booksTitleField.setText(getBookList(query).get(index).getTitle());
        booksAuthorField.setText(getBookList(query).get(index).getAuthor());
        booksLanguageField.setText(getBookList(query).get(index).getLanguage());
        booksPagesField.setText(Integer.toString(getBookList(query).get(index).getPages()));
        booksCategoryField.setText(getBookList(query).get(index).getCategory());
        booksPublisherField.setText(getBookList(query).get(index).getPublisher());
        booksYearField.setText(Integer.toString(getBookList(query).get(index).getYear()));
        booksPriceField.setText(Float.toString(getBookList(query).get(index).getPrice()));
        booksImage.setIcon(booksResizeImage(null, getBookList(query).get(index).getPicture()));
    }
    
    public void display(){
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserTabs().setVisible(true);
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        booksMainPanel = new javax.swing.JPanel();
        bookSearchPanel = new javax.swing.JPanel();
        booksSearchLabel = new javax.swing.JLabel();
        booksSearchField = new javax.swing.JTextField();
        booksSearchShowAllButton = new javax.swing.JButton();
        booksSearchButton = new javax.swing.JButton();
        booksToFirstButton = new javax.swing.JButton();
        booksPreviousButton = new javax.swing.JButton();
        booksNextButton = new javax.swing.JButton();
        booksToLastButton = new javax.swing.JButton();
        booksSearchResultPane = new javax.swing.JScrollPane();
        booksResultTable = new javax.swing.JTable();
        booksScrollInfo = new javax.swing.JScrollPane();
        booksInformationPanel = new javax.swing.JPanel();
        booksISBNLabel = new javax.swing.JLabel();
        booksISBNField = new javax.swing.JTextField();
        booksTitleField = new javax.swing.JTextField();
        booksTitleLabel = new javax.swing.JLabel();
        booksAuthorField = new javax.swing.JTextField();
        booksAuthorLabel = new javax.swing.JLabel();
        booksLanguageField = new javax.swing.JTextField();
        booksLanguageLabel = new javax.swing.JLabel();
        booksPagesField = new javax.swing.JTextField();
        booksPagesLabel = new javax.swing.JLabel();
        booksCategoryField = new javax.swing.JTextField();
        booksCategoryLabel = new javax.swing.JLabel();
        booksPublisherField = new javax.swing.JTextField();
        booksPublisherLabel = new javax.swing.JLabel();
        booksYearLabel = new javax.swing.JLabel();
        booksYearField = new javax.swing.JTextField();
        booksPriceField = new javax.swing.JTextField();
        booksPriceLabel = new javax.swing.JLabel();
        booksImage = new javax.swing.JLabel();
        bookOrderButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        booksMainPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        bookSearchPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        bookSearchPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        booksSearchLabel.setText("Enter the keywords of your book");

        booksSearchField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        booksSearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchFieldActionPerformed(evt);
            }
        });

        booksSearchShowAllButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksSearchShowAllButton.setText("Show All");
        booksSearchShowAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchShowAllButtonActionPerformed(evt);
            }
        });

        booksSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksSearchButton.setText("Search");
        booksSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchButtonActionPerformed(evt);
            }
        });

        booksToFirstButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksToFirstButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/resultset-first-icon.png"))); // NOI18N
        booksToFirstButton.setText("First");
        booksToFirstButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksToFirstButtonActionPerformed(evt);
            }
        });

        booksPreviousButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPreviousButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Arrow-previous-4-icon.png"))); // NOI18N
        booksPreviousButton.setText("Previous");
        booksPreviousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksPreviousButtonActionPerformed(evt);
            }
        });

        booksNextButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksNextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/next-icon.png"))); // NOI18N
        booksNextButton.setText("Next");
        booksNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksNextButtonActionPerformed(evt);
            }
        });

        booksToLastButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksToLastButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-go-last-view-icon.png"))); // NOI18N
        booksToLastButton.setText("Last");
        booksToLastButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksToLastButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bookSearchPanelLayout = new javax.swing.GroupLayout(bookSearchPanel);
        bookSearchPanel.setLayout(bookSearchPanelLayout);
        bookSearchPanelLayout.setHorizontalGroup(
            bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(booksSearchLabel)
                .addGap(18, 18, 18)
                .addComponent(booksSearchField)
                .addGap(62, 62, 62))
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addComponent(booksSearchButton)
                .addGap(51, 51, 51)
                .addComponent(booksSearchShowAllButton)
                .addGap(70, 70, 70)
                .addComponent(booksToFirstButton)
                .addGap(18, 18, 18)
                .addComponent(booksPreviousButton)
                .addGap(18, 18, 18)
                .addComponent(booksNextButton)
                .addGap(18, 18, 18)
                .addComponent(booksToLastButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bookSearchPanelLayout.setVerticalGroup(
            bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booksSearchLabel)
                    .addComponent(booksSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booksSearchShowAllButton)
                    .addComponent(booksSearchButton)
                    .addComponent(booksToFirstButton)
                    .addComponent(booksPreviousButton)
                    .addComponent(booksNextButton)
                    .addComponent(booksToLastButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        booksSearchResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        booksSearchResultPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        booksSearchResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        booksResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ISBN", "Title", "Author", "Language", "Pages", "Category", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        booksResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                booksResultTableMouseClicked(evt);
            }
        });
        booksSearchResultPane.setViewportView(booksResultTable);

        booksInformationPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        booksISBNLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksISBNLabel.setText("ISBN");

        booksISBNField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksTitleField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksTitleLabel.setText("Title");

        booksAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksAuthorLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksAuthorLabel.setText("Author");

        booksLanguageField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksLanguageLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksLanguageLabel.setText("Language");

        booksPagesField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPagesLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPagesLabel.setText("Pages");

        booksCategoryField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksCategoryLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksCategoryLabel.setText("Category");

        booksPublisherField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPublisherLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPublisherLabel.setText("Publisher");

        booksYearLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksYearLabel.setText("Publish Year");

        booksYearField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPriceField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPriceLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPriceLabel.setText("Price");

        booksImage.setBackground(new java.awt.Color(153, 204, 255));
        booksImage.setOpaque(true);

        bookOrderButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bookOrderButton.setText("Order This Book!");
        bookOrderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookOrderButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout booksInformationPanelLayout = new javax.swing.GroupLayout(booksInformationPanel);
        booksInformationPanel.setLayout(booksInformationPanelLayout);
        booksInformationPanelLayout.setHorizontalGroup(
            booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksInformationPanelLayout.createSequentialGroup()
                .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(booksInformationPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(booksPriceLabel)
                            .addComponent(booksPublisherLabel)
                            .addComponent(booksCategoryLabel)
                            .addComponent(booksPagesLabel)
                            .addComponent(booksAuthorLabel)
                            .addComponent(booksISBNLabel)
                            .addComponent(booksYearLabel)
                            .addComponent(booksLanguageLabel)
                            .addComponent(booksTitleLabel))
                        .addGap(50, 50, 50)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(booksISBNField, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(booksTitleField)
                            .addComponent(booksAuthorField)
                            .addComponent(booksLanguageField)
                            .addComponent(booksPagesField)
                            .addComponent(booksCategoryField)
                            .addComponent(booksPublisherField)
                            .addComponent(booksYearField)
                            .addComponent(booksPriceField))
                        .addGap(110, 110, 110)
                        .addComponent(booksImage, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(booksInformationPanelLayout.createSequentialGroup()
                        .addGap(391, 391, 391)
                        .addComponent(bookOrderButton)))
                .addContainerGap(194, Short.MAX_VALUE))
        );
        booksInformationPanelLayout.setVerticalGroup(
            booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksInformationPanelLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(booksImage, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(booksInformationPanelLayout.createSequentialGroup()
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksISBNLabel)
                            .addComponent(booksISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(booksTitleLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksAuthorLabel)
                            .addComponent(booksAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksLanguageLabel)
                            .addComponent(booksLanguageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksPagesLabel)
                            .addComponent(booksPagesField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksCategoryLabel)
                            .addComponent(booksCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksPublisherLabel)
                            .addComponent(booksPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(booksYearLabel)
                            .addComponent(booksYearField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(booksPriceLabel)
                            .addComponent(booksPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35)
                .addComponent(bookOrderButton)
                .addContainerGap(65, Short.MAX_VALUE))
        );

        booksScrollInfo.setViewportView(booksInformationPanel);

        javax.swing.GroupLayout booksMainPanelLayout = new javax.swing.GroupLayout(booksMainPanel);
        booksMainPanel.setLayout(booksMainPanelLayout);
        booksMainPanelLayout.setHorizontalGroup(
            booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(booksSearchResultPane)
                    .addComponent(bookSearchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(booksScrollInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        booksMainPanelLayout.setVerticalGroup(
            booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bookSearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(booksSearchResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(booksScrollInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Books", booksMainPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1059, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void booksSearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booksSearchFieldActionPerformed

    private void booksSearchShowAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchShowAllButtonActionPerformed
        // TODO add your handling code here:
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        booksShowBookList(currentBooksQuery);
    }//GEN-LAST:event_booksSearchShowAllButtonActionPerformed

    private void booksSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchButtonActionPerformed
        // TODO add your handling code here:
        String query = "SELECT * FROM Books WHERE isbn LIKE '%"+booksSearchField.getText()+"%' "
        + "OR title LIKE '%"+booksSearchField.getText()+"%' "
        + "OR author LIKE '%"+booksSearchField.getText()+"%'"
        + "OR language LIKE '%"+booksSearchField.getText()+"%'"
        + "OR pages LIKE '%"+booksSearchField.getText()+"%'"
        + "OR category LIKE '%"+booksSearchField.getText()+"%'"
        + "OR publisher LIKE '%"+booksSearchField.getText()+"%'"
        + "OR publishYear LIKE '%"+booksSearchField.getText()+"%'"
        + "OR price LIKE '%"+booksSearchField.getText()+"%';";
        setCurrentBooksQuery(query);
        booksShowBookList(currentBooksQuery);
    }//GEN-LAST:event_booksSearchButtonActionPerformed

    private void booksToFirstButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksToFirstButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            booksShowChosenBook(0, currentBooksQuery);
            currentPos = 0;
        }
        else
        JOptionPane.showMessageDialog(null, "You are currently seeing the top of our book list!");
    }//GEN-LAST:event_booksToFirstButtonActionPerformed

    private void booksPreviousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksPreviousButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            booksShowChosenBook(--currentPos, currentBooksQuery);
        }
        else
        JOptionPane.showMessageDialog(null, "You have reached the top of the list!");
    }//GEN-LAST:event_booksPreviousButtonActionPerformed

    private void booksNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksNextButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentBooksQuery).size()-1;
        if (currentPos != finalPos)
        booksShowChosenBook(++currentPos, currentBooksQuery);
        else
        JOptionPane.showMessageDialog(null, "You have reached the end of our bookstore!");
    }//GEN-LAST:event_booksNextButtonActionPerformed

    private void booksToLastButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksToLastButtonActionPerformed
        // TODO add your handling code here:
        if (currentBooksQuery == null)
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentBooksQuery).size()-1;
        if (currentPos != finalPos){
            booksShowChosenBook(finalPos, currentBooksQuery);
            currentPos = finalPos;
        }
        else
        JOptionPane.showMessageDialog(null, "You are currently seeing the end of our book list!");
    }//GEN-LAST:event_booksToLastButtonActionPerformed

    private void booksResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booksResultTableMouseClicked
        // TODO add your handling code here:
        if (currentBooksQuery == null)
        setCurrentBooksQuery(DEFAULT_BOOK_QUERY);
        int index = booksResultTable.getSelectedRow();
        booksShowChosenBook(index, currentBooksQuery);
        currentPos = index;
    }//GEN-LAST:event_booksResultTableMouseClicked

    private void bookOrderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookOrderButtonActionPerformed
        // TODO add your handling code here:
        if (booksISBNField.getText() != null && getUsername() != null){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("INSERT INTO Orders(username, isbn, order_date, order_status) VALUES (?, ?, ?, ?);");
                ps.setString(1, getUsername());
                ps.setString(2, booksISBNField.getText());
                String today = DateTimeFormatter.ofPattern("yyy/MM/dd").format(localDate);
                ps.setString(3, today);
                ps.setString(4, "Pending");
                
                JOptionPane.showMessageDialog(null, "Data Inserted Successfully!");
                booksShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(UserTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Order Failed!\nOne or more fields are empty!");
    }//GEN-LAST:event_bookOrderButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserTabs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bookOrderButton;
    private javax.swing.JPanel bookSearchPanel;
    private javax.swing.JTextField booksAuthorField;
    private javax.swing.JLabel booksAuthorLabel;
    private javax.swing.JTextField booksCategoryField;
    private javax.swing.JLabel booksCategoryLabel;
    private javax.swing.JTextField booksISBNField;
    private javax.swing.JLabel booksISBNLabel;
    private javax.swing.JLabel booksImage;
    private javax.swing.JPanel booksInformationPanel;
    private javax.swing.JTextField booksLanguageField;
    private javax.swing.JLabel booksLanguageLabel;
    private javax.swing.JPanel booksMainPanel;
    private javax.swing.JButton booksNextButton;
    private javax.swing.JTextField booksPagesField;
    private javax.swing.JLabel booksPagesLabel;
    private javax.swing.JButton booksPreviousButton;
    private javax.swing.JTextField booksPriceField;
    private javax.swing.JLabel booksPriceLabel;
    private javax.swing.JTextField booksPublisherField;
    private javax.swing.JLabel booksPublisherLabel;
    private javax.swing.JTable booksResultTable;
    private javax.swing.JScrollPane booksScrollInfo;
    private javax.swing.JButton booksSearchButton;
    private javax.swing.JTextField booksSearchField;
    private javax.swing.JLabel booksSearchLabel;
    private javax.swing.JScrollPane booksSearchResultPane;
    private javax.swing.JButton booksSearchShowAllButton;
    private javax.swing.JTextField booksTitleField;
    private javax.swing.JLabel booksTitleLabel;
    private javax.swing.JButton booksToFirstButton;
    private javax.swing.JButton booksToLastButton;
    private javax.swing.JTextField booksYearField;
    private javax.swing.JLabel booksYearLabel;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
