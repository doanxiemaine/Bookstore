/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package query;

/**
 *
 * @author trufmgajtgiof
 */
public class Book {
    private String isbn;
    private String title;
    private String language;
    private int pages;
    private String category;
    private String publisher;
    private int publishYear;
    private float price;
    private byte[] picture;
    private String author;
    
    public Book(String bid, String bname, String bauthor, String blang, int bpages, String bcat, String bpub, int byear, float bprice, byte[] img){
        isbn = bid;
        title = bname;
        author = bauthor;
        language = blang;
        pages = bpages;
        category = bcat;
        publisher = bpub;
        publishYear = byear;
        price = bprice;
        picture = img;
    }
    
    public String getISBN(){
        return isbn;
    }
    
    public String getTitle(){
        return title;
    }
    
    public String getAuthor(){
        return author;
    }
    
    public String getLanguage(){
        return language;
    }
    
    public int getPages(){
        return pages;
    }
    
    public String getCategory(){
        return category;
    }
    
    public String getPublisher(){
        return publisher;
    }
    
    public int getYear(){
        return publishYear;
    }
    
    public float getPrice(){
        return price;
    }
    
    public byte[] getPicture(){
        return picture;
    }
}
