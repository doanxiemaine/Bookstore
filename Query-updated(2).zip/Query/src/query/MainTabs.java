/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package query;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author trufmgajtgiof
 */
public class MainTabs extends javax.swing.JFrame {
    
    private int currentPos = 0; // displaying position of Books
    private static final String DEFAULT_BOOK_QUERY = "SELECT * FROM Books";
    private static final String DEFAULT_ORDER_QUERY = "SELECT * FROM Orders";
    private String currentQuery = null;
    
    public void setCurrentQuery(String query){
        currentQuery = query;
    }
    
    public String getCurrentQuery(){
        return currentQuery;
    }

    /**
     * Creates new form NewJFrame
     */
    public MainTabs() {
        initComponents(); // initialize GUI
        getConnection(); // connect to MS SQL Server
        adminShowBookList(DEFAULT_BOOK_QUERY); // show book list for admin tab
        booksShowBookList(DEFAULT_BOOK_QUERY); // show book list for user tab
        ordersShowOrdersList(DEFAULT_ORDER_QUERY);
    }
    
    String ImgPath = null;
    
    public Connection getConnection(){
        Connection con = null;
        try {
            con = DriverManager.getConnection( "jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true" );
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Not Connected");
            return null;
        }
    }
    
    public boolean checkInput(){
        if ( adminISBNField.getText() == null ||
                adminTitleField.getText() == null ||
                adminAuthorField.getText() == null ||
                adminLanguageField.getText() == null ||
                adminPagesField.getText() == null ||
                adminCategoryField.getText() == null ||
                adminPublisherField.getText() == null ||
                adminYearField.getText() == null ||
                adminPriceField.getText() == null )
            return false;
        else{
            try{
                Float.parseFloat(adminPriceField.getText());
                return true;
            }
            catch (Exception e){
                return false;
            }
        }
    }
    
    public ImageIcon adminResizeImage(String imagePath, byte[] pic){
        ImageIcon myImage = null;
        
        if (imagePath != null){
            myImage = new ImageIcon(imagePath);
        }
        else{
            myImage = new ImageIcon(pic);
        }
        
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(adminImage.getWidth(), adminImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        
        return image;
    }
    
    public ImageIcon booksResizeImage(String imagePath, byte[] pic){
        ImageIcon myImage = null;
        
        if (imagePath != null){
            myImage = new ImageIcon(imagePath);
        }
        else{
            myImage = new ImageIcon(pic);
        }
        
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(booksImage.getWidth(), booksImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        
        return image;
    }
    
    //display result table
    public ArrayList<Book> getBookList(String query){
        
        ArrayList<Book> bookList = new ArrayList<Book>();
        Connection con = getConnection();
            
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Book books;
            
            while (rs.next()){
                books = new Book(rs.getString("isbn"), rs.getString("title"), rs.getString("author"), rs.getString("language"), rs.getInt("pages"), rs.getString("category"), rs.getString("publisher"), Integer.parseInt(rs.getString("publishYear")), Float.parseFloat(rs.getString("price")),rs.getBytes("img"));
                bookList.add(books);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return bookList;
    }
    
    public ArrayList<Orders> getOrdersList(String query){
        
        ArrayList<Orders> ordersList = new ArrayList<Orders>();
        Connection con = getConnection();
            
        Statement st;
        ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(query);
            Orders orders;
            
            while (rs.next()){
                orders = new Orders(Integer.parseInt(rs.getString("order_ID")), rs.getString("username"), rs.getString("isbn"), rs.getString("order_date"), rs.getString("order_status"));
                ordersList.add(orders);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return ordersList;
    }
    
    public void ordersShowOrdersList(String query){
        ArrayList<Orders> result = getOrdersList(query);
        DefaultTableModel model = (DefaultTableModel)ordersResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[4];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getOrderID();
            currentRow[1] = result.get(i).getISBN();
            currentRow[2] = result.get(i).getDate();
            currentRow[3] = result.get(i).getStatus();
            
            
            model.addRow(currentRow);
        }
    }
    
    public void adminShowBookList(String query){
        ArrayList<Book> result = getBookList(query);
        DefaultTableModel model = (DefaultTableModel)adminResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[7];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getISBN();
            currentRow[1] = result.get(i).getTitle();
            currentRow[2] = result.get(i).getAuthor();
            currentRow[3] = result.get(i).getLanguage();
            currentRow[4] = result.get(i).getPages();
            currentRow[5] = result.get(i).getCategory();
            currentRow[6] = result.get(i).getPrice();
            
            model.addRow(currentRow);
        }
    }
    
    public void booksShowBookList(String query){
        ArrayList<Book> result = getBookList(query);
        DefaultTableModel model = (DefaultTableModel)booksResultTable.getModel();
        
        model.setRowCount(0);
        Object[] currentRow = new Object[7];
        for (int i = 0; i < result.size(); i++){
            currentRow[0] = result.get(i).getISBN();
            currentRow[1] = result.get(i).getTitle();
            currentRow[2] = result.get(i).getAuthor();
            currentRow[3] = result.get(i).getLanguage();
            currentRow[4] = result.get(i).getPages();
            currentRow[5] = result.get(i).getCategory();
            currentRow[6] = result.get(i).getPrice();
            
            model.addRow(currentRow);
        }
    }
    
    public void adminShowChosenBook(int index, String query){
        adminISBNField.setText(getBookList(query).get(index).getISBN());
        adminTitleField.setText(getBookList(query).get(index).getTitle());
        adminAuthorField.setText(getBookList(query).get(index).getAuthor());
        adminLanguageField.setText(getBookList(query).get(index).getLanguage());
        adminPagesField.setText(Integer.toString(getBookList(query).get(index).getPages()));
        adminCategoryField.setText(getBookList(query).get(index).getCategory());
        adminPublisherField.setText(getBookList(query).get(index).getPublisher());
        adminYearField.setText(Integer.toString(getBookList(query).get(index).getYear()));
        adminPriceField.setText(Float.toString(getBookList(query).get(index).getPrice()));
        adminImage.setIcon(adminResizeImage(null, getBookList(query).get(index).getPicture()));
    }
    
    public void booksShowChosenBook(int index, String query){
        booksISBNField.setText(getBookList(query).get(index).getISBN());
        booksTitleField.setText(getBookList(query).get(index).getTitle());
        booksAuthorField.setText(getBookList(query).get(index).getAuthor());
        booksLanguageField.setText(getBookList(query).get(index).getLanguage());
        booksPagesField.setText(Integer.toString(getBookList(query).get(index).getPages()));
        booksCategoryField.setText(getBookList(query).get(index).getCategory());
        booksPublisherField.setText(getBookList(query).get(index).getPublisher());
        booksYearField.setText(Integer.toString(getBookList(query).get(index).getYear()));
        booksPriceField.setText(Float.toString(getBookList(query).get(index).getPrice()));
        booksImage.setIcon(booksResizeImage(null, getBookList(query).get(index).getPicture()));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainTabsPane = new javax.swing.JTabbedPane();
        booksMainPanel = new javax.swing.JPanel();
        bookSearchPanel = new javax.swing.JPanel();
        booksSearchLabel = new javax.swing.JLabel();
        booksSearchField = new javax.swing.JTextField();
        booksSearchShowAllButton = new javax.swing.JButton();
        booksSearchButton = new javax.swing.JButton();
        booksToFirstButton = new javax.swing.JButton();
        booksPreviousButton = new javax.swing.JButton();
        booksNextButton = new javax.swing.JButton();
        booksToLastButton = new javax.swing.JButton();
        booksSearchResultPane = new javax.swing.JScrollPane();
        booksResultTable = new javax.swing.JTable();
        booksScrollInfo = new javax.swing.JScrollPane();
        booksInformationPanel = new javax.swing.JPanel();
        booksISBNLabel = new javax.swing.JLabel();
        booksISBNField = new javax.swing.JTextField();
        booksTitleField = new javax.swing.JTextField();
        booksTitleLabel = new javax.swing.JLabel();
        booksAuthorField = new javax.swing.JTextField();
        booksAuthorLabel = new javax.swing.JLabel();
        booksLanguageField = new javax.swing.JTextField();
        booksLanguageLabel = new javax.swing.JLabel();
        booksPagesField = new javax.swing.JTextField();
        booksPagesLabel = new javax.swing.JLabel();
        booksCategoryField = new javax.swing.JTextField();
        booksCategoryLabel = new javax.swing.JLabel();
        booksPublisherField = new javax.swing.JTextField();
        booksPublisherLabel = new javax.swing.JLabel();
        booksYearLabel = new javax.swing.JLabel();
        booksYearField = new javax.swing.JTextField();
        booksPriceField = new javax.swing.JTextField();
        booksPriceLabel = new javax.swing.JLabel();
        booksImage = new javax.swing.JLabel();
        bookOrderButton = new javax.swing.JButton();
        ordersPanel = new javax.swing.JPanel();
        ordersResultPane = new javax.swing.JScrollPane();
        ordersResultTable = new javax.swing.JTable();
        adminMainPanel = new javax.swing.JPanel();
        adminSearchPanel = new javax.swing.JPanel();
        adminSearchLabel = new javax.swing.JLabel();
        adminSearchField = new javax.swing.JTextField();
        adminSearchShowAllButton = new javax.swing.JButton();
        adminSearchButton = new javax.swing.JButton();
        adminToFirstButton = new javax.swing.JButton();
        adminPreviousButton = new javax.swing.JButton();
        adminNextButton = new javax.swing.JButton();
        adminToLastButton = new javax.swing.JButton();
        adminScrollInfo = new javax.swing.JScrollPane();
        adminInformationPanel = new javax.swing.JPanel();
        adminISBNLabel = new javax.swing.JLabel();
        adminISBNField = new javax.swing.JTextField();
        adminTitleField = new javax.swing.JTextField();
        adminTitleLabel = new javax.swing.JLabel();
        adminAuthorField = new javax.swing.JTextField();
        adminAuthorLabel = new javax.swing.JLabel();
        adminLanguageField = new javax.swing.JTextField();
        adminLanguageLabel = new javax.swing.JLabel();
        adminPagesField = new javax.swing.JTextField();
        adminPagesLabel = new javax.swing.JLabel();
        adminCategoryField = new javax.swing.JTextField();
        adminCategoryLabel = new javax.swing.JLabel();
        adminPublisherField = new javax.swing.JTextField();
        adminPublisherLabel = new javax.swing.JLabel();
        adminYearLabel = new javax.swing.JLabel();
        adminYearField = new javax.swing.JTextField();
        adminPriceField = new javax.swing.JTextField();
        adminPriceLabel = new javax.swing.JLabel();
        adminImage = new javax.swing.JLabel();
        chooseImgButton = new javax.swing.JButton();
        adminInsertButton = new javax.swing.JButton();
        adminUpdateButton = new javax.swing.JButton();
        adminDeleteButton = new javax.swing.JButton();
        adminSearchResultPane = new javax.swing.JScrollPane();
        adminResultTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bookstore Application");

        mainTabsPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Main Tabs", javax.swing.border.TitledBorder.RIGHT, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 20))); // NOI18N
        mainTabsPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksMainPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        bookSearchPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        bookSearchPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        booksSearchLabel.setText("Enter the keywords of your book");

        booksSearchField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        booksSearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchFieldActionPerformed(evt);
            }
        });

        booksSearchShowAllButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksSearchShowAllButton.setText("Show All");
        booksSearchShowAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchShowAllButtonActionPerformed(evt);
            }
        });

        booksSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksSearchButton.setText("Search");
        booksSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksSearchButtonActionPerformed(evt);
            }
        });

        booksToFirstButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksToFirstButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/resultset-first-icon.png"))); // NOI18N
        booksToFirstButton.setText("First");
        booksToFirstButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksToFirstButtonActionPerformed(evt);
            }
        });

        booksPreviousButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPreviousButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Arrow-previous-4-icon.png"))); // NOI18N
        booksPreviousButton.setText("Previous");
        booksPreviousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksPreviousButtonActionPerformed(evt);
            }
        });

        booksNextButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksNextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/next-icon.png"))); // NOI18N
        booksNextButton.setText("Next");
        booksNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksNextButtonActionPerformed(evt);
            }
        });

        booksToLastButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksToLastButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-go-last-view-icon.png"))); // NOI18N
        booksToLastButton.setText("Last");
        booksToLastButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksToLastButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bookSearchPanelLayout = new javax.swing.GroupLayout(bookSearchPanel);
        bookSearchPanel.setLayout(bookSearchPanelLayout);
        bookSearchPanelLayout.setHorizontalGroup(
            bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(booksSearchLabel)
                .addGap(18, 18, 18)
                .addComponent(booksSearchField, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
                .addGap(62, 62, 62))
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addComponent(booksSearchButton)
                .addGap(51, 51, 51)
                .addComponent(booksSearchShowAllButton)
                .addGap(70, 70, 70)
                .addComponent(booksToFirstButton)
                .addGap(18, 18, 18)
                .addComponent(booksPreviousButton)
                .addGap(18, 18, 18)
                .addComponent(booksNextButton)
                .addGap(18, 18, 18)
                .addComponent(booksToLastButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bookSearchPanelLayout.setVerticalGroup(
            bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bookSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booksSearchLabel)
                    .addComponent(booksSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(bookSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(booksSearchShowAllButton)
                    .addComponent(booksSearchButton)
                    .addComponent(booksToFirstButton)
                    .addComponent(booksPreviousButton)
                    .addComponent(booksNextButton)
                    .addComponent(booksToLastButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        booksSearchResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        booksSearchResultPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        booksSearchResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        booksResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ISBN", "Title", "Author", "Language", "Pages", "Category", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        booksResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                booksResultTableMouseClicked(evt);
            }
        });
        booksSearchResultPane.setViewportView(booksResultTable);

        booksInformationPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        booksISBNLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksISBNLabel.setText("ISBN");

        booksISBNField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksTitleField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksTitleLabel.setText("Title");

        booksAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksAuthorLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksAuthorLabel.setText("Author");

        booksLanguageField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksLanguageLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksLanguageLabel.setText("Language");

        booksPagesField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPagesLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPagesLabel.setText("Pages");

        booksCategoryField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksCategoryLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksCategoryLabel.setText("Category");

        booksPublisherField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPublisherLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPublisherLabel.setText("Publisher");

        booksYearLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksYearLabel.setText("Publish Year");

        booksYearField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPriceField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        booksPriceLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        booksPriceLabel.setText("Price");

        booksImage.setBackground(new java.awt.Color(153, 204, 255));
        booksImage.setOpaque(true);

        bookOrderButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        bookOrderButton.setText("Order This Book!");
        bookOrderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookOrderButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout booksInformationPanelLayout = new javax.swing.GroupLayout(booksInformationPanel);
        booksInformationPanel.setLayout(booksInformationPanelLayout);
        booksInformationPanelLayout.setHorizontalGroup(
            booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksInformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(booksPriceLabel)
                    .addComponent(booksPublisherLabel)
                    .addComponent(booksCategoryLabel)
                    .addComponent(booksPagesLabel)
                    .addComponent(booksAuthorLabel)
                    .addComponent(booksISBNLabel)
                    .addComponent(booksYearLabel)
                    .addComponent(booksLanguageLabel)
                    .addComponent(booksTitleLabel))
                .addGap(50, 50, 50)
                .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(booksISBNField, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                    .addComponent(booksTitleField)
                    .addComponent(booksAuthorField)
                    .addComponent(booksLanguageField)
                    .addComponent(booksPagesField)
                    .addComponent(booksCategoryField)
                    .addComponent(booksPublisherField)
                    .addComponent(booksYearField)
                    .addComponent(booksPriceField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addComponent(booksImage, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
            .addGroup(booksInformationPanelLayout.createSequentialGroup()
                .addGap(390, 390, 390)
                .addComponent(bookOrderButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        booksInformationPanelLayout.setVerticalGroup(
            booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksInformationPanelLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(booksImage, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(booksInformationPanelLayout.createSequentialGroup()
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksISBNLabel)
                            .addComponent(booksISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(booksTitleLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksAuthorLabel)
                            .addComponent(booksAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksLanguageLabel)
                            .addComponent(booksLanguageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksPagesLabel)
                            .addComponent(booksPagesField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksCategoryLabel)
                            .addComponent(booksCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(booksPublisherLabel)
                            .addComponent(booksPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(booksYearLabel)
                            .addComponent(booksYearField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(booksInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(booksPriceLabel)
                            .addComponent(booksPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addComponent(bookOrderButton)
                .addGap(36, 36, 36))
        );

        booksScrollInfo.setViewportView(booksInformationPanel);

        javax.swing.GroupLayout booksMainPanelLayout = new javax.swing.GroupLayout(booksMainPanel);
        booksMainPanel.setLayout(booksMainPanelLayout);
        booksMainPanelLayout.setHorizontalGroup(
            booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(booksSearchResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
                    .addComponent(bookSearchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(booksScrollInfo))
                .addContainerGap())
        );
        booksMainPanelLayout.setVerticalGroup(
            booksMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bookSearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(booksSearchResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(booksScrollInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainTabsPane.addTab("Books", booksMainPanel);

        ordersResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Your Orders History", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        ordersResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        ordersResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ordersResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order Number", "ISBN", "Order Date", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        ordersResultPane.setViewportView(ordersResultTable);

        javax.swing.GroupLayout ordersPanelLayout = new javax.swing.GroupLayout(ordersPanel);
        ordersPanel.setLayout(ordersPanelLayout);
        ordersPanelLayout.setHorizontalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ordersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ordersResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
                .addContainerGap())
        );
        ordersPanelLayout.setVerticalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ordersResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(600, Short.MAX_VALUE))
        );

        mainTabsPane.addTab("Orders", ordersPanel);

        adminSearchPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminSearchPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        adminSearchLabel.setText("Enter the keywords of your book");

        adminSearchField.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        adminSearchField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchFieldActionPerformed(evt);
            }
        });

        adminSearchShowAllButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminSearchShowAllButton.setText("Show All");
        adminSearchShowAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchShowAllButtonActionPerformed(evt);
            }
        });

        adminSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminSearchButton.setText("Search");
        adminSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminSearchButtonActionPerformed(evt);
            }
        });

        adminToFirstButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminToFirstButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/resultset-first-icon.png"))); // NOI18N
        adminToFirstButton.setText("First");
        adminToFirstButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminToFirstButtonActionPerformed(evt);
            }
        });

        adminPreviousButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPreviousButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Arrow-previous-4-icon.png"))); // NOI18N
        adminPreviousButton.setText("Previous");
        adminPreviousButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminPreviousButtonActionPerformed(evt);
            }
        });

        adminNextButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminNextButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/next-icon.png"))); // NOI18N
        adminNextButton.setText("Next");
        adminNextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminNextButtonActionPerformed(evt);
            }
        });

        adminToLastButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminToLastButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-go-last-view-icon.png"))); // NOI18N
        adminToLastButton.setText("Last");
        adminToLastButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminToLastButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout adminSearchPanelLayout = new javax.swing.GroupLayout(adminSearchPanel);
        adminSearchPanel.setLayout(adminSearchPanelLayout);
        adminSearchPanelLayout.setHorizontalGroup(
            adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminSearchPanelLayout.createSequentialGroup()
                        .addComponent(adminSearchLabel)
                        .addGap(18, 18, 18)
                        .addComponent(adminSearchField)
                        .addGap(62, 62, 62))
                    .addGroup(adminSearchPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(adminSearchButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminSearchShowAllButton)
                        .addGap(62, 62, 62)
                        .addComponent(adminToFirstButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminPreviousButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminNextButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminToLastButton)
                        .addGap(40, 40, 40))))
        );
        adminSearchPanelLayout.setVerticalGroup(
            adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminSearchPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminSearchLabel)
                    .addComponent(adminSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(adminSearchPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminSearchShowAllButton)
                    .addComponent(adminSearchButton)
                    .addComponent(adminToFirstButton)
                    .addComponent(adminPreviousButton)
                    .addComponent(adminNextButton)
                    .addComponent(adminToLastButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        adminInformationPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        adminInformationPanel.setAutoscrolls(true);
        adminInformationPanel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminISBNLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminISBNLabel.setText("ISBN");

        adminISBNField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminTitleField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminTitleLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminTitleLabel.setText("Title");

        adminAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminAuthorLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminAuthorLabel.setText("Author");

        adminLanguageField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminLanguageLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminLanguageLabel.setText("Language");

        adminPagesField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPagesLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPagesLabel.setText("Pages");

        adminCategoryField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        adminCategoryField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminCategoryFieldActionPerformed(evt);
            }
        });

        adminCategoryLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminCategoryLabel.setText("Category");

        adminPublisherField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPublisherLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPublisherLabel.setText("Publisher");

        adminYearLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminYearLabel.setText("Publish Year");

        adminYearField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPriceField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminPriceLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminPriceLabel.setText("Price");

        adminImage.setBackground(new java.awt.Color(102, 153, 255));
        adminImage.setOpaque(true);

        chooseImgButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        chooseImgButton.setText("Choose Picture");
        chooseImgButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseImgButtonActionPerformed(evt);
            }
        });

        adminInsertButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminInsertButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Button-Add-icon.png"))); // NOI18N
        adminInsertButton.setText("Insert");
        adminInsertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminInsertButtonActionPerformed(evt);
            }
        });

        adminUpdateButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminUpdateButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Actions-edit-redo-icon.png"))); // NOI18N
        adminUpdateButton.setText("Update");
        adminUpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminUpdateButtonActionPerformed(evt);
            }
        });

        adminDeleteButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        adminDeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/cancel-icon.png"))); // NOI18N
        adminDeleteButton.setText("Delete");
        adminDeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminDeleteButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout adminInformationPanelLayout = new javax.swing.GroupLayout(adminInformationPanel);
        adminInformationPanel.setLayout(adminInformationPanelLayout);
        adminInformationPanelLayout.setHorizontalGroup(
            adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(adminPublisherLabel)
                            .addComponent(adminYearLabel)
                            .addComponent(adminPriceLabel)
                            .addComponent(adminCategoryLabel)
                            .addComponent(adminPagesLabel)
                            .addComponent(adminLanguageLabel)
                            .addComponent(adminAuthorLabel)
                            .addComponent(adminTitleLabel)
                            .addComponent(adminISBNLabel))
                        .addGap(30, 30, 30)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(adminISBNField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                            .addComponent(adminTitleField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminAuthorField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminLanguageField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPagesField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminCategoryField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPublisherField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminYearField, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPriceField)))
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(adminInsertButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(adminUpdateButton)
                        .addGap(18, 18, 18)
                        .addComponent(adminDeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addComponent(adminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(chooseImgButton)
                .addGap(172, 172, 172))
        );
        adminInformationPanelLayout.setVerticalGroup(
            adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminInformationPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminInformationPanelLayout.createSequentialGroup()
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminISBNLabel)
                            .addComponent(adminISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminTitleLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminAuthorLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminLanguageField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminLanguageLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPagesField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPagesLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminCategoryLabel)
                            .addComponent(adminCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPublisherLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminYearField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminYearLabel))
                        .addGap(18, 18, 18)
                        .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(adminPriceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPriceLabel))
                        .addGap(42, 42, 42))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminInformationPanelLayout.createSequentialGroup()
                        .addComponent(adminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(chooseImgButton)
                        .addGap(10, 10, 10)))
                .addGroup(adminInformationPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminInsertButton)
                    .addComponent(adminUpdateButton)
                    .addComponent(adminDeleteButton))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        adminScrollInfo.setViewportView(adminInformationPanel);

        adminSearchResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        adminSearchResultPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        adminSearchResultPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        adminResultTable.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        adminResultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ISBN", "Title", "Author", "Language", "Pages", "Category", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminResultTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminResultTableMouseClicked(evt);
            }
        });
        adminSearchResultPane.setViewportView(adminResultTable);

        javax.swing.GroupLayout adminMainPanelLayout = new javax.swing.GroupLayout(adminMainPanel);
        adminMainPanel.setLayout(adminMainPanelLayout);
        adminMainPanelLayout.setHorizontalGroup(
            adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(adminSearchPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(adminScrollInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE)
                    .addComponent(adminSearchResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1007, Short.MAX_VALUE))
                .addContainerGap())
        );
        adminMainPanelLayout.setVerticalGroup(
            adminMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminMainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminSearchResultPane, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adminSearchPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adminScrollInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainTabsPane.addTab("Admin's Tools", adminMainPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainTabsPane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mainTabsPane)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void booksSearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_booksSearchFieldActionPerformed

    private void adminNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminNextButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentQuery).size()-1;
        if (currentPos != finalPos)
            adminShowChosenBook(++currentPos, currentQuery);
        else
            JOptionPane.showMessageDialog(null, "You have reached the end of our bookstore!");
    }//GEN-LAST:event_adminNextButtonActionPerformed

    private void adminSearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminSearchFieldActionPerformed

    private void adminToFirstButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminToFirstButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            adminShowChosenBook(0, currentQuery);
            currentPos = 0;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the top of our book list!");
    }//GEN-LAST:event_adminToFirstButtonActionPerformed

    private void adminDeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminDeleteButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("DELETE FROM Books WHERE isbn = ?;");
                ps.setString(1, adminISBNField.getText());
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Book Deleted Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Delete Failed!\nBook's ISBN not found!\n It is best that you search for the book first, then choose from it!");
    }//GEN-LAST:event_adminDeleteButtonActionPerformed

    private void adminUpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminUpdateButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("UPDATE Books SET title = ?, author = ?, language = ?, pages = ?, category = ?, publisher = ?, publishYear = ?, price = ?, img = ? WHERE isbn = ?;");
                ps.setString(10, adminISBNField.getText());
                ps.setString(1, adminTitleField.getText());
                ps.setString(2, adminAuthorField.getText());
                ps.setString(3, adminLanguageField.getText());
                ps.setString(4, adminPagesField.getText());
                ps.setString(5, adminCategoryField.getText());
                ps.setString(6, adminPublisherField.getText());
                ps.setString(7, adminYearField.getText());
                ps.setString(8, adminPriceField.getText());

                InputStream img = new FileInputStream(new File(ImgPath));
                ps.setBlob(9, img);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Data Updated Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
            JOptionPane.showMessageDialog(null, "Update Failed!\nOne or more fields are empty!");
    }//GEN-LAST:event_adminUpdateButtonActionPerformed

    private void adminInsertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminInsertButtonActionPerformed
        // TODO add your handling code here:
        if (checkInput() && (ImgPath != null)){
            try {
                Connection con = getConnection();
                PreparedStatement ps = con.prepareStatement("INSERT INTO Books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");
                ps.setString(1, adminISBNField.getText());
                ps.setString(2, adminTitleField.getText());
                ps.setString(3, adminAuthorField.getText());
                ps.setString(4, adminLanguageField.getText());
                ps.setString(5, adminPagesField.getText());
                ps.setString(6, adminCategoryField.getText());
                ps.setString(7, adminPublisherField.getText());
                ps.setString(8, adminYearField.getText());
                ps.setString(9, adminPriceField.getText());

                InputStream img = new FileInputStream(new File(ImgPath));
                ps.setBlob(10, img);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(null, "Data Inserted Successfully!");
                adminShowBookList(DEFAULT_BOOK_QUERY);
            } catch (Exception ex) {
                Logger.getLogger(MainTabs.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        JOptionPane.showMessageDialog(null, "Insertion Failed!\nOne or more fields are empty!");
    }//GEN-LAST:event_adminInsertButtonActionPerformed

    private void chooseImgButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseImgButtonActionPerformed
        // TODO add your handling code here:
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));

        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION){
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            System.out.println(path);
            adminImage.setIcon(adminResizeImage(path, null));
            ImgPath = path;
        }
        else
        System.out.println("No file was selected");
    }//GEN-LAST:event_chooseImgButtonActionPerformed

    private void adminCategoryFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminCategoryFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminCategoryFieldActionPerformed

    private void adminToLastButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminToLastButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentQuery).size()-1;
        if (currentPos != finalPos){
            adminShowChosenBook(finalPos, currentQuery);
            currentPos = finalPos;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the end of our book list!");
    }//GEN-LAST:event_adminToLastButtonActionPerformed

    private void adminPreviousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminPreviousButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            adminShowChosenBook(--currentPos, currentQuery);
        }
        else
            JOptionPane.showMessageDialog(null, "You have reached the top of the list!");
    }//GEN-LAST:event_adminPreviousButtonActionPerformed

    private void booksToFirstButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksToFirstButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            booksShowChosenBook(0, currentQuery);
            currentPos = 0;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the top of our book list!");
    }//GEN-LAST:event_booksToFirstButtonActionPerformed

    private void booksPreviousButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksPreviousButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        if (currentPos != 0){
            booksShowChosenBook(--currentPos, currentQuery);
        }
        else
            JOptionPane.showMessageDialog(null, "You have reached the top of the list!");
    }//GEN-LAST:event_booksPreviousButtonActionPerformed

    private void booksNextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksNextButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentQuery).size()-1;
        if (currentPos != finalPos)
            booksShowChosenBook(++currentPos, currentQuery);
        else
            JOptionPane.showMessageDialog(null, "You have reached the end of our bookstore!");
    }//GEN-LAST:event_booksNextButtonActionPerformed

    private void booksToLastButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksToLastButtonActionPerformed
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int finalPos = getBookList(currentQuery).size()-1;
        if (currentPos != finalPos){
            booksShowChosenBook(finalPos, currentQuery);
            currentPos = finalPos;
        }
        else
            JOptionPane.showMessageDialog(null, "You are currently seeing the end of our book list!");
    }//GEN-LAST:event_booksToLastButtonActionPerformed

    private void adminResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminResultTableMouseClicked
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int index = adminResultTable.getSelectedRow();
        adminShowChosenBook(index, currentQuery);
        currentPos = index;
    }//GEN-LAST:event_adminResultTableMouseClicked

    private void booksResultTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booksResultTableMouseClicked
        // TODO add your handling code here:
        if (currentQuery == null)
            setCurrentQuery(DEFAULT_BOOK_QUERY);
        int index = booksResultTable.getSelectedRow();
        booksShowChosenBook(index, currentQuery);
        currentPos = index;
    }//GEN-LAST:event_booksResultTableMouseClicked

    private void adminSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchButtonActionPerformed
        // TODO add your handling code here:
        
        String query = "SELECT * FROM Books WHERE isbn LIKE '%"+adminSearchField.getText()+"%' "
                + "OR title LIKE '%"+adminSearchField.getText()+"%' "
                + "OR author LIKE '%"+adminSearchField.getText()+"%'"
                + "OR language LIKE '%"+adminSearchField.getText()+"%'"
                + "OR pages LIKE '%"+adminSearchField.getText()+"%'"
                + "OR category LIKE '%"+adminSearchField.getText()+"%'"
                + "OR publisher LIKE '%"+adminSearchField.getText()+"%'"
                + "OR publishYear LIKE '%"+adminSearchField.getText()+"%'"
                + "OR price LIKE '%"+adminSearchField.getText()+"%';";
        setCurrentQuery(query);    
        adminShowBookList(currentQuery);        
        
    }//GEN-LAST:event_adminSearchButtonActionPerformed

    private void adminSearchShowAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminSearchShowAllButtonActionPerformed
        // TODO add your handling code here:
        setCurrentQuery(DEFAULT_BOOK_QUERY);
        adminShowBookList(currentQuery);
    }//GEN-LAST:event_adminSearchShowAllButtonActionPerformed

    private void booksSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchButtonActionPerformed
        // TODO add your handling code here:
        String query = "SELECT * FROM Books WHERE isbn LIKE '%"+booksSearchField.getText()+"%' "
                + "OR title LIKE '%"+booksSearchField.getText()+"%' "
                + "OR author LIKE '%"+booksSearchField.getText()+"%'"
                + "OR language LIKE '%"+booksSearchField.getText()+"%'"
                + "OR pages LIKE '%"+booksSearchField.getText()+"%'"
                + "OR category LIKE '%"+booksSearchField.getText()+"%'"
                + "OR publisher LIKE '%"+booksSearchField.getText()+"%'"
                + "OR publishYear LIKE '%"+booksSearchField.getText()+"%'"
                + "OR price LIKE '%"+booksSearchField.getText()+"%';";
        setCurrentQuery(query);    
        booksShowBookList(currentQuery); 
    }//GEN-LAST:event_booksSearchButtonActionPerformed

    private void booksSearchShowAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksSearchShowAllButtonActionPerformed
        // TODO add your handling code here:
        setCurrentQuery(DEFAULT_BOOK_QUERY);
        booksShowBookList(currentQuery);
    }//GEN-LAST:event_booksSearchShowAllButtonActionPerformed

    private void bookOrderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookOrderButtonActionPerformed
        // TODO add your handling code here:
        //String query = "INSERT INTO Orders VALUES(?, ?, ?, ?)"
    }//GEN-LAST:event_bookOrderButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainTabs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainTabs().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adminAuthorField;
    private javax.swing.JLabel adminAuthorLabel;
    private javax.swing.JTextField adminCategoryField;
    private javax.swing.JLabel adminCategoryLabel;
    private javax.swing.JButton adminDeleteButton;
    private javax.swing.JTextField adminISBNField;
    private javax.swing.JLabel adminISBNLabel;
    private javax.swing.JLabel adminImage;
    private javax.swing.JPanel adminInformationPanel;
    private javax.swing.JButton adminInsertButton;
    private javax.swing.JTextField adminLanguageField;
    private javax.swing.JLabel adminLanguageLabel;
    private javax.swing.JPanel adminMainPanel;
    private javax.swing.JButton adminNextButton;
    private javax.swing.JTextField adminPagesField;
    private javax.swing.JLabel adminPagesLabel;
    private javax.swing.JButton adminPreviousButton;
    private javax.swing.JTextField adminPriceField;
    private javax.swing.JLabel adminPriceLabel;
    private javax.swing.JTextField adminPublisherField;
    private javax.swing.JLabel adminPublisherLabel;
    private javax.swing.JTable adminResultTable;
    private javax.swing.JScrollPane adminScrollInfo;
    private javax.swing.JButton adminSearchButton;
    private javax.swing.JTextField adminSearchField;
    private javax.swing.JLabel adminSearchLabel;
    private javax.swing.JPanel adminSearchPanel;
    private javax.swing.JScrollPane adminSearchResultPane;
    private javax.swing.JButton adminSearchShowAllButton;
    private javax.swing.JTextField adminTitleField;
    private javax.swing.JLabel adminTitleLabel;
    private javax.swing.JButton adminToFirstButton;
    private javax.swing.JButton adminToLastButton;
    private javax.swing.JButton adminUpdateButton;
    private javax.swing.JTextField adminYearField;
    private javax.swing.JLabel adminYearLabel;
    private javax.swing.JButton bookOrderButton;
    private javax.swing.JPanel bookSearchPanel;
    private javax.swing.JTextField booksAuthorField;
    private javax.swing.JLabel booksAuthorLabel;
    private javax.swing.JTextField booksCategoryField;
    private javax.swing.JLabel booksCategoryLabel;
    private javax.swing.JTextField booksISBNField;
    private javax.swing.JLabel booksISBNLabel;
    private javax.swing.JLabel booksImage;
    private javax.swing.JPanel booksInformationPanel;
    private javax.swing.JTextField booksLanguageField;
    private javax.swing.JLabel booksLanguageLabel;
    private javax.swing.JPanel booksMainPanel;
    private javax.swing.JButton booksNextButton;
    private javax.swing.JTextField booksPagesField;
    private javax.swing.JLabel booksPagesLabel;
    private javax.swing.JButton booksPreviousButton;
    private javax.swing.JTextField booksPriceField;
    private javax.swing.JLabel booksPriceLabel;
    private javax.swing.JTextField booksPublisherField;
    private javax.swing.JLabel booksPublisherLabel;
    private javax.swing.JTable booksResultTable;
    private javax.swing.JScrollPane booksScrollInfo;
    private javax.swing.JButton booksSearchButton;
    private javax.swing.JTextField booksSearchField;
    private javax.swing.JLabel booksSearchLabel;
    private javax.swing.JScrollPane booksSearchResultPane;
    private javax.swing.JButton booksSearchShowAllButton;
    private javax.swing.JTextField booksTitleField;
    private javax.swing.JLabel booksTitleLabel;
    private javax.swing.JButton booksToFirstButton;
    private javax.swing.JButton booksToLastButton;
    private javax.swing.JTextField booksYearField;
    private javax.swing.JLabel booksYearLabel;
    private javax.swing.JButton chooseImgButton;
    private javax.swing.JTabbedPane mainTabsPane;
    private javax.swing.JPanel ordersPanel;
    private javax.swing.JScrollPane ordersResultPane;
    private javax.swing.JTable ordersResultTable;
    // End of variables declaration//GEN-END:variables
}
