package query;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.*;

public class GUI extends JFrame{
    static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static final String DATABASE_URL = "jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true";
    
    static final String DEFAULT_QUERY = "SELECT b.isbn AS ISBN, b.title AS Title, a.authorName AS Author, b.category AS Category, b.publisher AS Publisher, b.publishYear AS [Publish Year], b.price AS Price FROM Authors a, Books b WHERE a.authorID = b.authorID";
    static final String DEFAULT_Author_QUERY = "SELECT authorID AS ID, authorName AS Name, yob AS [Year Of Birth] FROM Authors";
    
    private ResultSetTableModel bookTableModel;
    private ResultSetTableModel authorTableModel;
    
    private javax.swing.JButton addAuthorButton;
    private javax.swing.JButton addBookButton;
    private javax.swing.JLabel authorCategoryLabel;
    private javax.swing.JScrollPane authorResultPane;
    private javax.swing.JPanel authorsPanel;
    private javax.swing.JScrollPane bookResultPane;
    private javax.swing.JPanel booksPanel;
    private javax.swing.JPanel booksPanel2;
    private javax.swing.JButton deleteAuthorButton;
    private javax.swing.JButton deleteBookButton;
    private javax.swing.JButton editAuthorButton;
    private javax.swing.JButton editBookButton;
    private javax.swing.JButton makeOrderButton;
    private javax.swing.JPanel makeOrderPanel;
    private javax.swing.JTextField orderAuthorField;
    private javax.swing.JLabel orderAuthorLabel;
    private javax.swing.JTextField orderCategoryField;
    private javax.swing.JTextField orderISBNField;
    private javax.swing.JLabel orderISBNLabel;
    private javax.swing.JTextField orderPublishYearField;
    private javax.swing.JLabel orderPublishYearLabel;
    private javax.swing.JTextField orderPublisherField;
    private javax.swing.JLabel orderPublisherLabel;
    private javax.swing.JTextField orderTitleField;
    private javax.swing.JLabel orderTitleLabel;
    private javax.swing.JPanel ordersPanel;
    private javax.swing.JScrollPane prevOrdersPane;
    private javax.swing.JButton searchAuthorButton;
    private javax.swing.JComboBox<String> searchAuthorComboBox;
    private javax.swing.JTextField searchAuthorField;
    private javax.swing.JLabel searchAuthorLabel;
    private javax.swing.JPanel searchAuthorPanel;
    private javax.swing.JButton searchBookButton;
    private javax.swing.JComboBox<String> searchBookComboBox;
    private javax.swing.JTextField searchBookField;
    private javax.swing.JLabel searchBookLabel;
    private javax.swing.JPanel searchBookPanel;
    private javax.swing.JButton searchButton1;
    private javax.swing.JComboBox<String> searchComboBox1;
    private javax.swing.JTextField searchField1;
    private javax.swing.JLabel searchLabel1;
    private javax.swing.JPanel searchPanel1;
    private javax.swing.JButton showAllAuthorsButton;
    private javax.swing.JButton showAllBooksButton;
    private javax.swing.JButton showAllButton1;
    private javax.swing.JPanel subAuthorPanel;
    private javax.swing.JPanel subBookPanel;
    private javax.swing.JTabbedPane tabsPane;
    private javax.swing.JScrollPane usingPane;
    private javax.swing.JPanel usingPanel;
    
    public GUI(){
        super( "Displaying Query Results" );
        try {
            bookTableModel = new ResultSetTableModel( JDBC_DRIVER, DATABASE_URL, DEFAULT_QUERY );
            authorTableModel = new ResultSetTableModel( JDBC_DRIVER, DATABASE_URL, DEFAULT_Author_QUERY );
        }
        catch ( ClassNotFoundException classNotFound ) {
            JOptionPane.showMessageDialog( null, "Cloudscape driver not found", "Driver not found", JOptionPane.ERROR_MESSAGE );
            System.exit( 1 );
        }
        
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
            bookTableModel.disconnectFromDatabase();
            System.exit( 1 );
        }
        initComponents();
    }
    
    private void initComponents() {
        
        JTable bookResultTable = new JTable( bookTableModel );
        JTable authorResultTable = new JTable( authorTableModel );
        tabsPane = new javax.swing.JTabbedPane();
        booksPanel = new javax.swing.JPanel();        
        searchBookPanel = new javax.swing.JPanel();
        searchBookLabel = new javax.swing.JLabel();
        searchBookComboBox = new javax.swing.JComboBox<>();
        searchBookField = new javax.swing.JTextField();
        searchBookButton = new javax.swing.JButton();
        showAllBooksButton = new javax.swing.JButton();
        subBookPanel = new javax.swing.JPanel();
        addBookButton = new javax.swing.JButton();
        editBookButton = new javax.swing.JButton();
        deleteBookButton = new javax.swing.JButton();
        bookResultPane = new javax.swing.JScrollPane(bookResultTable);
        authorsPanel = new javax.swing.JPanel();
        booksPanel2 = new javax.swing.JPanel();
        searchAuthorPanel = new javax.swing.JPanel();
        searchAuthorLabel = new javax.swing.JLabel();
        searchAuthorComboBox = new javax.swing.JComboBox<>();
        searchAuthorField = new javax.swing.JTextField();
        searchAuthorButton = new javax.swing.JButton();
        showAllAuthorsButton = new javax.swing.JButton();
        subAuthorPanel = new javax.swing.JPanel();
        addAuthorButton = new javax.swing.JButton();
        editAuthorButton = new javax.swing.JButton();
        deleteAuthorButton = new javax.swing.JButton();
        authorResultPane = new javax.swing.JScrollPane(authorResultTable);
        ordersPanel = new javax.swing.JPanel();
        makeOrderPanel = new javax.swing.JPanel();
        orderISBNLabel = new javax.swing.JLabel();
        orderISBNField = new javax.swing.JTextField();
        orderTitleField = new javax.swing.JTextField();
        orderTitleLabel = new javax.swing.JLabel();
        orderAuthorField = new javax.swing.JTextField();
        orderAuthorLabel = new javax.swing.JLabel();
        orderCategoryField = new javax.swing.JTextField();
        authorCategoryLabel = new javax.swing.JLabel();
        orderPublisherField = new javax.swing.JTextField();
        orderPublisherLabel = new javax.swing.JLabel();
        orderPublishYearField = new javax.swing.JTextField();
        orderPublishYearLabel = new javax.swing.JLabel();
        makeOrderButton = new javax.swing.JButton();
        prevOrdersPane = new javax.swing.JScrollPane();
        usingPanel = new javax.swing.JPanel();
        usingPane = new javax.swing.JScrollPane();
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bookstore App");

        tabsPane.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        searchBookLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        searchBookLabel.setText("Seach a book by");

        searchBookComboBox.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        searchBookComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ISBN", "Keyword" }));

        searchBookField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        searchBookButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        searchBookButton.setText("Search!");
        searchBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBookButtonActionPerformed(evt);
            }
        });

        showAllBooksButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        showAllBooksButton.setText("Show All");
        showAllBooksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showAllBooksButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout searchBookPanelLayout = new javax.swing.GroupLayout(searchBookPanel);
        searchBookPanel.setLayout(searchBookPanelLayout);
        searchBookPanelLayout.setHorizontalGroup(
            searchBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchBookPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchBookLabel)
                .addGap(18, 18, 18)
                .addComponent(searchBookComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(searchBookField, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(searchBookButton)
                .addGap(29, 29, 29)
                .addComponent(showAllBooksButton, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        searchBookPanelLayout.setVerticalGroup(
            searchBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchBookPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(searchBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchBookLabel)
                    .addComponent(searchBookComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBookField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBookButton)
                    .addComponent(showAllBooksButton))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        addBookButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        addBookButton.setText("Add A Book");
        addBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBookButtonActionPerformed(evt);
            }
        });

        editBookButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        editBookButton.setText("Edit Book");
        editBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBookButtonActionPerformed(evt);
            }
        });

        deleteBookButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        deleteBookButton.setText("Delete Book");
        deleteBookButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBookButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout subBookPanelLayout = new javax.swing.GroupLayout(subBookPanel);
        subBookPanel.setLayout(subBookPanelLayout);
        subBookPanelLayout.setHorizontalGroup(
            subBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subBookPanelLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(addBookButton)
                .addGap(186, 186, 186)
                .addComponent(editBookButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(deleteBookButton)
                .addGap(51, 51, 51))
        );
        subBookPanelLayout.setVerticalGroup(
            subBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subBookPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(subBookPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addBookButton)
                    .addComponent(editBookButton)
                    .addComponent(deleteBookButton))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        bookResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        bookResultPane.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout booksPanelLayout = new javax.swing.GroupLayout(booksPanel);
        booksPanel.setLayout(booksPanelLayout);
        booksPanelLayout.setHorizontalGroup(
            booksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, booksPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(booksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bookResultPane)
                    .addComponent(searchBookPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(subBookPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        booksPanelLayout.setVerticalGroup(
            booksPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchBookPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(subBookPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabsPane.addTab("Book", booksPanel);

        searchAuthorLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        searchAuthorLabel.setText("Seach an author by");

        searchAuthorComboBox.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        searchAuthorComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Keyword" }));

        searchAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        searchAuthorButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        searchAuthorButton.setText("Search!");
        searchAuthorButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchAuthorButtonActionPerformed(evt);
            }
        });

        showAllAuthorsButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        showAllAuthorsButton.setText("Show All");
        showAllAuthorsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showAllAuthorsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout searchAuthorPanelLayout = new javax.swing.GroupLayout(searchAuthorPanel);
        searchAuthorPanel.setLayout(searchAuthorPanelLayout);
        searchAuthorPanelLayout.setHorizontalGroup(
            searchAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchAuthorPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchAuthorLabel)
                .addGap(18, 18, 18)
                .addComponent(searchAuthorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(searchAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(searchAuthorButton)
                .addGap(29, 29, 29)
                .addComponent(showAllAuthorsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        searchAuthorPanelLayout.setVerticalGroup(
            searchAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(searchAuthorPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(searchAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchAuthorLabel)
                    .addComponent(searchAuthorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchAuthorButton)
                    .addComponent(showAllAuthorsButton))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        addAuthorButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        addAuthorButton.setText("Add An Author");
        addAuthorButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAuthorButtonButtonActionPerformed(evt);
            }
        });

        editAuthorButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        editAuthorButton.setText("Edit Author");
        editAuthorButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editAuthorButtonButtonActionPerformed(evt);
            }
        });

        deleteAuthorButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        deleteAuthorButton.setText("Delete Author");
        deleteAuthorButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAuthorButtonButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout subAuthorPanelLayout = new javax.swing.GroupLayout(subAuthorPanel);
        subAuthorPanel.setLayout(subAuthorPanelLayout);
        subAuthorPanelLayout.setHorizontalGroup(
            subAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subAuthorPanelLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(addAuthorButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(editAuthorButton)
                .addGap(134, 134, 134)
                .addComponent(deleteAuthorButton)
                .addGap(51, 51, 51))
        );
        subAuthorPanelLayout.setVerticalGroup(
            subAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(subAuthorPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(subAuthorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addAuthorButton)
                    .addComponent(editAuthorButton)
                    .addComponent(deleteAuthorButton))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        authorResultPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Authors", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 16))); // NOI18N
        authorResultPane.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout booksPanel2Layout = new javax.swing.GroupLayout(booksPanel2);
        booksPanel2.setLayout(booksPanel2Layout);
        booksPanel2Layout.setHorizontalGroup(
            booksPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(booksPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(authorResultPane)
                    .addGroup(booksPanel2Layout.createSequentialGroup()
                        .addGroup(booksPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(searchAuthorPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(subAuthorPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        booksPanel2Layout.setVerticalGroup(
            booksPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(booksPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(searchAuthorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(authorResultPane, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(subAuthorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout authorsPanelLayout = new javax.swing.GroupLayout(authorsPanel);
        authorsPanel.setLayout(authorsPanelLayout);
        authorsPanelLayout.setHorizontalGroup(
            authorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 893, Short.MAX_VALUE)
            .addGroup(authorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(authorsPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(booksPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        authorsPanelLayout.setVerticalGroup(
            authorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 458, Short.MAX_VALUE)
            .addGroup(authorsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(authorsPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(booksPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        tabsPane.addTab("Authors", authorsPanel);

        makeOrderPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Make A New Order", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        orderISBNLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        orderISBNLabel.setText("ISBN");

        orderISBNField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        orderTitleField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        orderTitleLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        orderTitleLabel.setText("Title");

        orderAuthorField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        

        orderAuthorLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        orderAuthorLabel.setText("Author");

        orderCategoryField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        authorCategoryLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        authorCategoryLabel.setText("Category");

        orderPublisherField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        orderPublisherLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        orderPublisherLabel.setText("Publisher");

        orderPublishYearField.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        orderPublishYearLabel.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        orderPublishYearLabel.setText("Publish Year");

        makeOrderButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        makeOrderButton.setText("Make Order");
        makeOrderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                makeOrderButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout makeOrderPanelLayout = new javax.swing.GroupLayout(makeOrderPanel);
        makeOrderPanel.setLayout(makeOrderPanelLayout);
        makeOrderPanelLayout.setHorizontalGroup(
            makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(makeOrderPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(makeOrderPanelLayout.createSequentialGroup()
                        .addComponent(orderPublishYearLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(orderPublishYearField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(makeOrderPanelLayout.createSequentialGroup()
                        .addComponent(orderPublisherLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59)
                        .addComponent(orderPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(makeOrderPanelLayout.createSequentialGroup()
                        .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(orderISBNLabel)
                            .addComponent(orderTitleLabel)
                            .addComponent(orderAuthorLabel)
                            .addComponent(authorCategoryLabel))
                        .addGap(70, 70, 70)
                        .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(orderCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(orderTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(orderISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(makeOrderPanelLayout.createSequentialGroup()
                                .addComponent(orderAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67)
                                .addComponent(makeOrderButton)))))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        makeOrderPanelLayout.setVerticalGroup(
            makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(makeOrderPanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orderISBNLabel)
                    .addComponent(orderISBNField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orderTitleLabel)
                    .addComponent(orderTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orderAuthorLabel)
                    .addComponent(orderAuthorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(makeOrderButton))
                .addGap(18, 18, 18)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(authorCategoryLabel)
                    .addComponent(orderCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orderPublisherLabel)
                    .addComponent(orderPublisherField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(makeOrderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(orderPublishYearLabel)
                    .addComponent(orderPublishYearField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        prevOrdersPane.setViewportBorder(javax.swing.BorderFactory.createTitledBorder(null, "Your Previous Orders", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        javax.swing.GroupLayout ordersPanelLayout = new javax.swing.GroupLayout(ordersPanel);
        ordersPanel.setLayout(ordersPanelLayout);
        ordersPanelLayout.setHorizontalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ordersPanelLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(makeOrderPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(82, Short.MAX_VALUE))
            .addGroup(ordersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(prevOrdersPane)
                .addContainerGap())
        );
        ordersPanelLayout.setVerticalGroup(
            ordersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ordersPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(prevOrdersPane, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(makeOrderPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        tabsPane.addTab("Orders", ordersPanel);

        usingPane.setViewportBorder(javax.swing.BorderFactory.createTitledBorder(null, "You Are Currently Using", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N
        usingPane.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N

        javax.swing.GroupLayout usingPanelLayout = new javax.swing.GroupLayout(usingPanel);
        usingPanel.setLayout(usingPanelLayout);
        usingPanelLayout.setHorizontalGroup(
            usingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(usingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(usingPane, javax.swing.GroupLayout.DEFAULT_SIZE, 869, Short.MAX_VALUE)
                .addContainerGap())
        );
        usingPanelLayout.setVerticalGroup(
            usingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(usingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(usingPane, javax.swing.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE)
                .addContainerGap())
        );

        tabsPane.addTab("Using", usingPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabsPane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabsPane)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }// </editor-fold>                        

    private void searchAuthorButtonActionPerformed(java.awt.event.ActionEvent evt) {                                                   
        // TODO add your handling code here:
        try {
            if (searchAuthorComboBox.getSelectedItem() == "ID"){
                if (searchAuthorField.getText() != null){
                    String newQuery = DEFAULT_Author_QUERY+" WHERE authorID = "+searchAuthorField.getText();
                    authorTableModel.setQuery( newQuery );
                }
                else{
                    authorTableModel.setQuery( DEFAULT_Author_QUERY );
                } 
            }
            else if (searchAuthorComboBox.getSelectedItem() == "Keyword"){
                if (searchAuthorField.getText() != null){
                    String newQueryy = DEFAULT_Author_QUERY+" AND authorName LIKE '%"+searchAuthorField.getText()+"%';";
                    authorTableModel.setQuery( newQueryy );
                }
                else{
                    authorTableModel.setQuery( DEFAULT_Author_QUERY );
                }  
            } 
        }
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
            try {
                authorTableModel.setQuery( DEFAULT_Author_QUERY );
            }
            catch ( SQLException sqlException2 ) {
                JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                authorTableModel.disconnectFromDatabase();
                System.exit( 1 );
            }
        }
    }
    
    private void showAllAuthorsButtonActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
        try {
                    authorTableModel.setQuery( DEFAULT_Author_QUERY );
            }
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
            try {
                authorTableModel.setQuery( DEFAULT_Author_QUERY );
            }
            catch ( SQLException sqlException2 ) {
                JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                authorTableModel.disconnectFromDatabase();
                System.exit( 1 );
            }
        }                     
    }

    private void searchBookButtonActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
        try {
            if (searchBookComboBox.getSelectedItem() == "ISBN"){
                if (searchBookField.getText() != null){
                    String newQuery = DEFAULT_QUERY+" AND b.isbn = "+searchBookField.getText();
                    bookTableModel.setQuery( newQuery );
                }
                else{
                    bookTableModel.setQuery( DEFAULT_QUERY );
                } 
            }
            else if (searchBookComboBox.getSelectedItem() == "Keyword"){
                if (searchBookField.getText() != null){
                    String newQueryy = DEFAULT_QUERY+" AND b.title LIKE '%"+searchBookField.getText()+"%';";
                    bookTableModel.setQuery( newQueryy );
                }
                else{
                    bookTableModel.setQuery( DEFAULT_QUERY );
                }  
            } 
        }
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
            try {
                bookTableModel.setQuery( DEFAULT_QUERY );
            }
            catch ( SQLException sqlException2 ) {
                JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                bookTableModel.disconnectFromDatabase();
                System.exit( 1 );
            }
        }                     
    }                                                

    private void showAllBooksButtonActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
        try {
                    bookTableModel.setQuery( DEFAULT_QUERY );
            }
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
            try {
                bookTableModel.setQuery( DEFAULT_QUERY );
            }
            catch ( SQLException sqlException2 ) {
                JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                bookTableModel.disconnectFromDatabase();
                System.exit( 1 );
            }
        }                     
    }
    
    private void addAuthorButtonButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
        AddAuthors addThisAuthor = new AddAuthors();
    }
    
    private void editAuthorButtonButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
        EditAuthors editThisAuthor = new EditAuthors();
    }
    
    private void deleteAuthorButtonButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
        DeleteAuthors deleteThisAuthor = new DeleteAuthors();
    }

    private void makeOrderButtonActionPerformed(java.awt.event.ActionEvent evt) {                                                
        // TODO add your handling code here:
    }                                               

    private void addBookButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
        AddBooks addThisBook = new AddBooks();
    } 
    
    private void editBookButtonActionPerformed(java.awt.event.ActionEvent evt) {
        EditBooks editThisBook = new EditBooks();
    }
    
    private void deleteBookButtonActionPerformed(java.awt.event.ActionEvent evt) {
        DeleteBooks deleteThisBook = new DeleteBooks();
    }    
    
    public static void main( String args[] ) {
        new GUI();
    }
}
