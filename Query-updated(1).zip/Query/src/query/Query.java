package query;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.*;

public class Query extends JFrame{
    static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static final String DATABASE_URL = "jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true";
    
    static final String DEFAULT_QUERY = "SELECT b.isbn, b.title, a.authorID, b.category, b.publisher, b.publishYear, b.price FROM Authors a, Books b WHERE b.authorID = a.authorID";
    
    private ResultSetTableModel tableModel;
    private JTextArea queryArea;
    
    public Query(){
        super( "Displaying Query Results" );
        try {
            tableModel = new ResultSetTableModel( JDBC_DRIVER, DATABASE_URL, DEFAULT_QUERY );
            queryArea = new JTextArea( DEFAULT_QUERY, 3, 100 );
            queryArea.setWrapStyleWord( true );
            queryArea.setLineWrap( true );
            JScrollPane scrollPane = new JScrollPane( queryArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER );
            JButton submitButton = new JButton( "Submit Query" );
            
            Box box = Box.createHorizontalBox();
            box.add( scrollPane );
            box.add( submitButton );
            JTable resultTable = new JTable( tableModel );
            Container c = getContentPane();
            c.add( box, BorderLayout.NORTH );
            c.add( new JScrollPane( resultTable ), BorderLayout.CENTER );
            
            
            submitButton.addActionListener(
                    new ActionListener() {
                        public void actionPerformed( ActionEvent event ){
                            try {
                                tableModel.setQuery( queryArea.getText() );
                            }
                            catch ( SQLException sqlException ) {
                                JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
                                try {
                                    tableModel.setQuery( DEFAULT_QUERY );
                                    queryArea.setText( DEFAULT_QUERY );
                                }
                                catch ( SQLException sqlException2 ) {
                                    JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                                    tableModel.disconnectFromDatabase();
                                    System.exit( 1 );
                                }
                            }
                        }
                    }
            );
            setSize( 500, 250 );
            setVisible( true );
        }
        catch ( ClassNotFoundException classNotFound ) {
            JOptionPane.showMessageDialog( null, "Cloudscape driver not found", "Driver not found", JOptionPane.ERROR_MESSAGE );
            System.exit( 1 );
        }
        
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
            tableModel.disconnectFromDatabase();
            System.exit( 1 );
        }
        
        setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        addWindowListener(
                new WindowAdapter() {
                    public void windowClosed( WindowEvent event ){
                        tableModel.disconnectFromDatabase();
                        System.exit( 0 );
                    }
                }
        );
    }
    
    public static void main( String args[] ) {
        new Query();
    }
}
