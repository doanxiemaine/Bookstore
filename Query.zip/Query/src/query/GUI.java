package query;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.*;

public class GUI extends JFrame{
    static final String JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static final String DATABASE_URL = "jdbc:sqlserver://TRUFMGAJTGIOF\\DEV1:1433;databaseName=Bookstore;integratedSecurity=true";
    
    static final String DEFAULT_QUERY = "SELECT b.isbn, b.title, a.authorID, b.category, b.publisher, b.publishYear, b.price FROM Authors a, Books b WHERE b.authorID = a.authorID";
    
    private ResultSetTableModel tableModel;
    
    private javax.swing.JPanel isbnPanel = new javax.swing.JPanel();
    private javax.swing.JPanel keywordPanel = new javax.swing.JPanel();
    private javax.swing.JLabel isbnLabel = new javax.swing.JLabel();
    private javax.swing.JTextField isbnField = new javax.swing.JTextField();
    private javax.swing.JLabel keywordLabel = new javax.swing.JLabel();
    private javax.swing.JTextField keywordField = new javax.swing.JTextField();
    private javax.swing.JButton isbnSearchButton = new javax.swing.JButton();
    private javax.swing.JTabbedPane tabPane = new javax.swing.JTabbedPane();
    private javax.swing.JButton keywordSearchButton = new javax.swing.JButton();;
    
    public GUI(){
        super( "Displaying Query Results" );
        try {
            tableModel = new ResultSetTableModel( JDBC_DRIVER, DATABASE_URL, DEFAULT_QUERY );
        }
        catch ( ClassNotFoundException classNotFound ) {
            JOptionPane.showMessageDialog( null, "Cloudscape driver not found", "Driver not found", JOptionPane.ERROR_MESSAGE );
            System.exit( 1 );
        }
        
        catch ( SQLException sqlException ) {
            JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
            tableModel.disconnectFromDatabase();
            System.exit( 1 );
        }
        drawGUI();
    }
    
    public void drawGUI(){        
        JTable resultTable = new JTable( tableModel );
        javax.swing.JScrollPane result = new javax.swing.JScrollPane(resultTable);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        result.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Our Books", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        tabPane.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search Your Book", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14))); // NOI18N

        isbnLabel.setText("ISBN");

        isbnSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        isbnSearchButton.setText("SEARCH!");        

        javax.swing.GroupLayout isbnPanelLayout = new javax.swing.GroupLayout(isbnPanel);
        isbnPanel.setLayout(isbnPanelLayout);
        isbnPanelLayout.setHorizontalGroup(
            isbnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(isbnPanelLayout.createSequentialGroup()
                .addGroup(isbnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(isbnPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(isbnLabel)
                        .addGap(63, 63, 63)
                        .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(isbnPanelLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(isbnSearchButton)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        isbnPanelLayout.setVerticalGroup(
            isbnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(isbnPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(isbnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(isbnLabel)
                    .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(isbnSearchButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabPane.addTab("By ISBN", isbnPanel);

        keywordLabel.setText("Keyword");       

        keywordSearchButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        keywordSearchButton.setText("SEARCH!");        

        javax.swing.GroupLayout keywordPanelLayout = new javax.swing.GroupLayout(keywordPanel);
        keywordPanel.setLayout(keywordPanelLayout);
        keywordPanelLayout.setHorizontalGroup(
            keywordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(keywordPanelLayout.createSequentialGroup()
                .addGroup(keywordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(keywordPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(keywordLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                        .addComponent(keywordField, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(keywordPanelLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(keywordSearchButton)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        keywordPanelLayout.setVerticalGroup(
            keywordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(keywordPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(keywordPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(keywordLabel)
                    .addComponent(keywordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(keywordSearchButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabPane.addTab("By Keyword", keywordPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(result)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(tabPane, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(130, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tabPane, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(result, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        
            isbnSearchButton.addActionListener(
                    new ActionListener() {
                        public void actionPerformed( ActionEvent event ){
                            try {
                                if (isbnField.getText() != null){
                                    String newQuery = DEFAULT_QUERY+" AND b.isbn = "+isbnField.getText();
                                    tableModel.setQuery( newQuery );
                                }
                                else{
                                    tableModel.setQuery( DEFAULT_QUERY );
                                }                                
                            }
                            catch ( SQLException sqlException ) {
                                JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
                                try {
                                    tableModel.setQuery( DEFAULT_QUERY );
                                }
                                catch ( SQLException sqlException2 ) {
                                    JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                                    tableModel.disconnectFromDatabase();
                                    System.exit( 1 );
                                }
                            }
                        }
                    }
            );
                    
                    keywordSearchButton.addActionListener(
                    new ActionListener() {
                        public void actionPerformed( ActionEvent event ){
                            try {
                                if (keywordField.getText() != null){
                                    String newQueryy = DEFAULT_QUERY+" AND b.title LIKE '%"+keywordField.getText()+"%';";
                                    tableModel.setQuery( newQueryy );
                                }
                                else{
                                    tableModel.setQuery( DEFAULT_QUERY );
                                }                                
                            }
                            catch ( SQLException sqlException ) {
                                JOptionPane.showMessageDialog( null, sqlException.getMessage(), "Database error",JOptionPane.ERROR_MESSAGE );
                                try {
                                    tableModel.setQuery( DEFAULT_QUERY );
                                }
                                catch ( SQLException sqlException2 ) {
                                    JOptionPane.showMessageDialog( null, sqlException2.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE );
                                    tableModel.disconnectFromDatabase();
                                    System.exit( 1 );
                                }
                            }
                        }
                    }
            );
            setSize( 800, 450 );
            setVisible( true );
            setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        addWindowListener(
                new WindowAdapter() {
                    public void windowClosed( WindowEvent event ){
                        tableModel.disconnectFromDatabase();
                        System.exit( 0 );
                    }
                }
        );
    }
    
    public static void main( String args[] ) {
        new GUI();
    }
}
